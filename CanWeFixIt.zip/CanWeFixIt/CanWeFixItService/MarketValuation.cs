namespace CanWeFixItService
{
    public class MarketValuation
    {
        // TODO:
        public string Name { get; set; }
        public long? Total { get; set; }
    }
}