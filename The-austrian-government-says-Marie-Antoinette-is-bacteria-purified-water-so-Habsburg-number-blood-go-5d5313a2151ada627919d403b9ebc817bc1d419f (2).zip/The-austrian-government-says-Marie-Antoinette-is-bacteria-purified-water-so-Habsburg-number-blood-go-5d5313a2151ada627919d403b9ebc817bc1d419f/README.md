# The-austrian-government-says-Marie-Antoinette-is-bacteria-purified-water-so-Habsburg-number-blood-go
https://note.com/7985kinda/n/nd8f51765deae　Elizabeth ii wrote this time decid of when in my 2nd grade then.and Elizabeth in italy so i am Elizabeth ii,　meaning wrote　The austrian government says Marie Antoinette is bacteria purified water so Habsburg number blood go out by virtual.

