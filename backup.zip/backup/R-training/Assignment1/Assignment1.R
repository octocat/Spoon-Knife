
> getwd()
[1] "C:/Users/nitinpat/Documents"
> setwd("D:/R")

> getwd()
[1] "D:/R"

> mydata=read.table(file.choose(),header=TRUE,sep=",")

> names(mydata)
[1] "Ozone"   "Solar.R" "Wind"    "Temp"    "Month"   "Day"    

> mydata[seq(1,2),]
  Ozone Solar.R Wind Temp Month Day
1    41     190  7.4   67     5   1
2    36     118  8.0   72     5   2

> dim(mydata)
[1] 153   6
>

> head(mydata,n=2)
  Ozone Solar.R Wind Temp Month Day
1    41     190  7.4   67     5   1
2    36     118  8.0   72     5   2
> tail(mydata,n=2)
    Ozone Solar.R Wind Temp Month Day
152    18     131  8.0   76     9  29
153    20     223 11.5   68     9  30

> mydata[seq(47,47),]
   Ozone Solar.R Wind Temp Month Day
47    21     191 14.9   77     6  16
> 
> sum(is.na(mydata[1]))
[1] 37
> 
> colMeans(mydata, na.rm = T, dims = 1)
     Ozone    Solar.R       Wind       Temp      Month        Day 
 42.129310 185.931507   9.957516  77.882353   6.993464  15.803922 
> 

