##Q.A)Identify data type for each variable. If data type of variable not in appropriate format then convert it into right format. ( pclass is factor and age is integer)
str(data)

data$Survived<-as.factor(data$Survived)
str(data$Survived)

data$Pclass<-as.factor(data$Pclass)
str(data$Survived)


##Q.B)Identify which variables having missing/blanks/NA values
sapply(data, function(x) sum(is.na(x)))


##Q.C)IF age variable having missing/blanks/NA replace it by average
if(sum(is.na(data$Age))> 0)
{
	print("missing/blanks/NA values are present")
	data$Age[is.na(data$Age)]<-mean(data$Age,na.rm=T)
	data$Age
}


##Q.D)IF embarked variable having missing/blanks/NA replace it by mode
if(sum(is.na(data$Embarked))>0)
{
	print("missing/blanks/NA values are present")
}else
{
	print("No missing/blanks/NA values")
}


##Q.E)Plot the histogram for Age and Fare variable and note down lowest and highest interval with frequency
hist(rpois(data$Age,2),col='pink')
hist(rpois(data$Fare,3),col='yellow',add=T)


##Q.F)Which Pclass was most impacted on survival?
> f1<-table(data$Survived)
> f1

  0   1 
549 342 



##Q.G)Which Port of Embarkation was most impacted on survival?




##Q.H)Draw stack bar chart for variable survival against sex




##Q.I)Divide these data into 70:30 ratio randomly (say 70% data is training and 30% data is testing)
 # this data has 150 rows 
 nrow(mydata) 
  
 # splitdf function will return a list of training and testing sets 
 splitdf <- function(dataframe, seed=NULL) { 
 	if (!is.null(seed)) set.seed(seed) 
 	index <- 1:nrow(dataframe) 
 	trainindex <- sample(index, trunc(length(index)*0.7)) 
 	trainset <- dataframe[trainindex, ] 
 	testset <- dataframe[-trainindex, ] 
 	list(trainset=trainset,testset=testset) 
 } 
  
 #apply the function 
 splits <- splitdf(mydata, seed=808) 
  
 #it returns a list - two data frames called trainset and testset 
 str(splits) 



##Q.J)Identify survival rate for training and testing dataset same or not?
