#R code for getting working directory
getwd()
[1] "C:/Users/nitinpat/Documents"

#R code for setting working directory
setwd("D:/R/Business Analytics using R")

#importing data in R
mydata<-read.csv("CAX_Startup_Data.csv",header=TRUE,as.is=T)

#R code for replacing �No Info� and 'blanks' with NA 
mydata[mydata=="No Info"]<-NA
mydata[mydata==""]<-NA

#R code for converting column as date 
mydata$Est..Founding.Date<-as.Date(mydata$Est..Founding.Date,"%m/%d/%y")
mydata$Last.Funding.Date<-as.Date(mydata$Last.Funding.Date,"%m/%d/%y")

#R code for checking data-type
str(mydata$Est..Founding.Date)
output:
Date[1:472], format: NA NA NA NA NA NA NA NA NA NA NA NA NA NA ...

str(mydata$Last.Funding.Date)
output:
Date[1:472], format: NA NA NA NA NA NA NA NA NA NA NA NA NA NA ...

#display column header of data
colnames(mydata)
output:
[1] "Company_Name"                                                                                                                     
[2] "Dependent.Company.Status"                                                                                                         
[3] "year.of.founding" 
......................
[116] "Renown.score"  

#R code for converting character vector to numeric 
#noting columns that needs to be converted to numeric
col<-c(3:5,10,11,18:23,25,61,66,68:70,72,74,88,92,94:96,98,99,102:116)

#using for loop for converting column as numeric 
for(i in col)
{
	mydata[,i]<-as.numeric(mydata[,i])
}
output:
Warning message:
NAs introduced by coercion 

#R code for checking data-type
str(mydata)
output:
'data.frame':   472 obs. of  116 variables:
 $ Company_Name             : chr  "Company1" "Company2" "Company3" "Company4" ...
 $ Dependent.Company.Status : chr  "Success" "Success" "Success" "Success" ...
 $ year.of.founding         : num  NA 2011 2011 2009
 ..............

#R code for calculationg missing value for each variable
mis_val<-sapply(mydata, function(x) sum(is.na(x)))
mis_val
output:
 Company_Name              0 
 Dependent.Company.Status  0 
 year.of.founding         59 
 .........................
    
#R code for Percent missing value for each variable
percent_mis<-round((mis_val/nrow(mydata))*100,1)
percent_mis
output:
 Company_Name               0.0 
 Dependent.Company.Status   0.0 
 year.of.founding          12.5
 ............................

#R code for making data frame with variable and missing value percent for filtering 
name<-row.names(percent_mis)

pcnt_mis_var<-cbind(name,percent_mis)
pcnt_mis_var
output:
                                 percent_mis
Company_Name                        0.0
Dependent.Company.Status            0.0
year.of.founding                   12.5
Age.of.company.in.years            12.5
...................

row.names(pcnt_mis_var)<-NULL

results <- data.frame(variable=1:116,pcnt_mis_var)
output:
 results
    variable percent_mis
1          1         0.0
2          2         0.0
3          3        12.5
........................

str(pcnt_mis_var)
output:
 num [1:116, 1] 0 0 12.5 12.5 13.8 31.6 26.3 6.4 29.7 35.2 ...
 - attr(*, "dimnames")=List of 2
  ..$ : NULL
  ..$ : chr "percent_mis"

#R code for keeping only variables with less than 40% missing
new_var<-results$variable[which(results$percent_mis<=40)]
new_mydata<-mydata[new_var]

dim(new_mydata)
output:
[1] 472 112

#R code for separating data frame for more than 40% missing
other_var<-results$variable[which(results$percent_mis>40)]
other_mydata<-mydata[other_var]

dim(other_mydata)
output:
[1] 472   4


#-------------------------------------


#R code for Separating data frame for numeric variables
cnt_df <- new_mydata[sapply(new_mydata,is.numeric)]

#R code for Separating data frame for numeric variables
cnt_var<-colnames(cnt_df)
var<-colnames(new_mydata) %in% cnt_var
char_df<-mydata[!var]


#R code for checking distribution of continuous variable for outlier detection and missing values 
#For continuous variable
summary(cnt_df$Team.size.all.employees)
output:
   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's 
   1.00   10.00   16.50   69.49   50.00 5000.00      68 

quantile(cnt_df$Team.size.all.employees,probs=seq(0,1,by=0.05),na.rm=T)
output:
    0%     5%    10%    15%    20%    25%    30%    35%    40% 
   1.0    3.0    4.0    6.0    8.0   10.0   10.0   10.0   11.0 
   45%    50%    55%    60%    65%    70%    75%    80%    85% 
  14.0   16.5   23.0   30.0   40.0   50.0   50.0   50.0   50.0 
   90%    95%   100% 
  80.0  200.0 5000.0 

#R code for checking distribution of categorical variabl
table(char_df$Local.or.global.player,useNA="always")
output:
 global  Global  GLObaL  GLOBAL   local   Local   LOCAL local   
     90      93       2      52      95      99      16       1 
   <NA> 
     24 

#R code for convert a variable to uppercase
char_df$Local.or.global.player<-toupper(char_df$Local.or.global.player)

#R code to check again for any inconsistency 
table(char_df$Local.or.global.player,useNA="always")
output: 
GLOBAL   LOCAL	    LOCAL      <NA>      
237     	210		1         24

#R code for trimming whitespaces
char_df$Local.or.global.player<-trimws(char_df$Local.or.global.player)
table(char_df$Local.or.global.player,useNA="always")
output:
GLOBAL  LOCAL   <NA> 
   237    211     24 

#R code for Recoding variable levels and converting to factor variable 
char_df$Local.or.global.player[char_df$Local.or.global.player=='LOCAL']<-0
char_df$Local.or.global.player[char_df$Local.or.global.player=='GLOBAL']<-1
char_df$Local.or.global.player<-as.factor(char_df$Local.or.global.player)
str(char_df$Local.or.global.player)
output:
Factor w/ 2 levels "0","1": 2 1 1 1 1 1 1 1 1 2 ...

#R code for Missing value treatment using median 
cnt_df$Team.size.all.employees[is.na(cnt_df$Team.size.all.employees)]<-
median(cnt_df$Team.size.all.employees,na.rm=T)

mean(cnt_df$Employee.Count)

median(cnt_df$Employee.Count,na.rm=T)


#R code for Function to calculate mode 
Mode<-function(x){
  u<-unique(x)
  u[which.max(tabulate(match(x,u)))]
}

#R code for filling missing values with mode  
char_df$Local.or.global.player[is.na(char_df$Local.or.global.player)]<-
 Mode(char_df$Local.or.global.player)

#R code to write CSV
write.csv(new_mydata,file="NewStartup.csv")

#R code of boxplot of employee count 
#boxplot(cnt_df$Employee.Count,main="boxplot of employee count",ylab="Employee Count")

#R code of histogram of employee count 
hist(cnt_df$Employee.Count,main="Histogram of employee count",xlab="",ylab="Employee Count")


library(ggplot2)
ggplot(cnt_df, aes(x=Employee.Count))+
geom_histogram(binwidth=5, colour="black", fill="white")+
geom_vline(aes(xintercept=median(Employee.Count, na.rm=T)),
color="red", linetype="dashed", size=1)+
ggtitle("Histogram of Employee count")+  
xlab("Employee Count") +
ylab("Frequency")+
theme_light()

#R code of box plot to see differnce in mean of team size w.r.t two categories of dependent 
ggplot(cnt_df, aes(x=char_df$Dependent.Company.Status,y=cnt_df$Team.size.all.employees,                     
fill=char_df$Dependent.Company.Status)) +   
xlab("Dependent Company Status") +
ylab("Team Size All Employees")+ 
geom_boxplot()


#R code of data preparation for bar chart 
#avg_emp<-aggregate(as.numeric(cnt_df$Team.size.all.employees),                     
#by=list(as.factor(cnt_df$Dependent.Company.Status)),                             
#FUN=mean, na.rm=T) 
#colnames(avg_emp)<-c("company.status","Avg.Employee.size")  


#R code of bar chart to check for difference in mean 
#ggplot(avg_emp, aes(x = company.status, y = Avg.Employee.size)) +   
#geom_bar(stat = "identity")


#R code of t-test for checking difference in mean 
t.test(cnt_df$Team.size.all.employees~char_df$Dependent.Company.Status)
output:
        Welch Two Sample t-test

data:  cnt_df$Team.size.all.employees by char_df$Dependent.Company.Status
t = -1.6681, df = 374.37, p-value = 0.09614
alternative hypothesis: true difference in means is not equal to 0
95 percent confidence interval:
 -89.932080   7.379886
sample estimates:
 mean in group Failed mean in group Success 
             35.17964              76.45574 

#R code of tabulating data for chi-sq test
tab<- table(char_df$Dependent.Company.Status,char_df$Local.or.global.player)

#R code of chi-sq test for categorical variable 
chisq.test(tab) 
output:
        Pearson's Chi-squared test with Yates' continuity correction

data:  tab
X-squared = 59.517, df = 1, p-value = 1.212e-14