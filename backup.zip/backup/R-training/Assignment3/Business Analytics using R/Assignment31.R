duration = faithful$eruptions      
waiting = faithful$waiting          
plot(duration, waiting,xlab="Eruption duration",ylab="Time waited",col=c("blue","red"))          