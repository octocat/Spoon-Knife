# Preprocessing
# R code to get current working directory
getwd()

# R code to set working directory
setwd("D:/R/Assignment4/")

# R code to import data
data <- read.csv(file.choose(), header <- TRUE, sep <- ",")

# R code to get data-types of all variables
str(data)


# Transformation to corresponding scores according to LACE
# R code to transform Hlos to Length of stay score
data$Hlos[which((data$Hlos >= 4) & (data$Hlos <= 6))] <- 4
data$Hlos[which((data$Hlos >= 7) & (data$Hlos <= 13))] <- 5
data$Hlos[which(data$Hlos >= 14)] <- 7

# R code to transform DEMAdmNo to Acuity of admission score
data$DEMAdmNo[which(data$DEMAdmNo == 1)] <- 3

# R code to transform ICD_Class to Comorbidities score
data$ICD_Class <- as.character(data$ICD_Class)
data$ICD_Class[which((data$ICD_Class == "Previous myocardial infarction") | 
				    (data$ICD_Class == "Cerebrovascular disease ") | 
				    (data$ICD_Class == "Peripheral vascular disease") | 
					(data$ICD_Class == "Diabetes without complications"))] <- "1"

data$ICD_Class[which((data$ICD_Class == "Congestive heart failure") | 
				    (data$ICD_Class == "Diabetes with end organ damage") | 
				    (data$ICD_Class == "Chronic pulmonary disease") | 
					(data$ICD_Class == "Mild liver or renal disease") | 
					(data$ICD_Class == "Any tumor"))] <- "2"

data$ICD_Class[which((data$ICD_Class == "Dementia") | 
				    (data$ICD_Class == "Connective Tissue Disease"))] <- "3"

data$ICD_Class[which((data$ICD_Class == "AIDS") | 
				    (data$ICD_Class == "Moderate Or Severe Liver Disease") | 
					(data$ICD_Class == "Metastatic Solid Tumor"))] <- "5"

# R code to transform ED.visits to Emergency department visits score
data$ED.visits[which(data$ED.visits > 4)] <- 4

#R code to convert data-type of ICD_Class to integer
data$ICD_Class <- as.integer(data$ICD_Class)

# R code to insert new column riskScore to .csv file
data$riskScore <- data$Hlos + data$DEMAdmNo + data$ICD_Class + data$ED.visits

# R code to insert new column riskType to .csv file
data$riskType[which(data$riskScore < 10)] <- "No Risk of Readmission"
data$riskType[which(data$riskScore >= 10)] <- "Risk of Readmission"

# R code to create new .csv file
write.csv(data, file <- "new_data_nitin.csv")
