--1]DDL STATEMENTS

CREATE DATABASE BookStoreDB
--use master
--drop database BookStoreDB
SP_HELPDB BookStoreDB

USE BookStoreDB

--Creating Tables
CREATE TABLE dbo.Author
(
	AuthorId int NOT NULL,
	AuthorName char(30) NOT NULL,
	DateOfBirth date NULL,
	State char(30) NULL,
	City char(30) NULL,
	Phone int NULL
)

SP_HELP 'dbo.Author'

CREATE TABLE dbo.Publisher
(
	PublisherId int NOT NULL,
	PublisherName char(30) NOT NULL,
	DateOfBirth date NULL,
	State char(30) NULL,
	City char(30) NULL,
	Phone int NULL
)

SP_HELP 'dbo.Publisher'

CREATE TABLE dbo.Category
(
	CategoryId int NOT NULL,
	CategoryName char(30) NOT NULL,
	Description char(50) NOT NULL
)

SP_HELP 'dbo.Category'

CREATE TABLE dbo.Book
(
	BookId int NOT NULL,
	Title char(50) NOT NULL,
	Description char(50) NOT NULL
)

SP_HELP 'dbo.Book'

CREATE TABLE Orders
(
	OrderId int NOT NULL,
	Date date NOT NULL,
	Quantity int NOT NULL,
	UnitPrice int NOT NULL,
	ShippingAddress char(50) NOT NULL
)

SP_HELP 'Orders'

--Applying Primary Key constraint on each table
ALTER TABLE dbo.Author
ADD CONSTRAINT PK_AuthorId PRIMARY KEY(AuthorId)

ALTER TABLE dbo.Publisher
ADD CONSTRAINT pk_PublisherId PRIMARY KEY(PublisherId)

ALTER TABLE dbo.category
ADD CONSTRAINT pk_CategoryId PRIMARY KEY(CategoryId)

ALTER TABLE dbo.Book
ADD CONSTRAINT pk_BookId PRIMARY KEY(BookId)

ALTER TABLE dbo.Orders
ADD CONSTRAINT pk_OrderId PRIMARY KEY(OrderId)

ALTER TABLE dbo.Orders
ADD CHECK(Quantity>1)

--Adding new column in Book Table
ALTER TABLE dbo.Book
ADD Price INT NULL

--Creating relationships among tables

--1)Relationship between tables namely "Book" and "Category"
--Adding new column in Book table
ALTER TABLE dbo.Book
ADD CategoryId INT NOT NULL

--Adding foreign key
ALTER TABLE dbo.Book
ADD CONSTRAINT fk_CategoryId FOREIGN KEY(CategoryId) REFERENCES dbo.category(CategoryId)

--2)Relationship between tables namely "Book" and "Publisher"
--Adding new column in Book table
ALTER TABLE dbo.Book
ADD PublisherId INT NOT NULL

--Adding foreign key
ALTER TABLE dbo.Book
ADD CONSTRAINT fk_PublisherId FOREIGN KEY(PublisherId) REFERENCES dbo.Publisher(PublisherId)

--3)Relationship between tables namely "Book" and "Author"
--Creating new table
CREATE TABLE dbo.BookAuthor
(
	AuthorId INT NOT NULL,
	BookId INT NOT NULL,	
	CONSTRAINT fk_AuthorId FOREIGN KEY(AuthorId) REFERENCES dbo.Author(AuthorId),
	CONSTRAINT fk_BookId FOREIGN KEY(BookId) REFERENCES dbo.Book(BookId),
	CONSTRAINT pk_BookAuthorId PRIMARY KEY(AuthorId,BookId)
)

SP_HELP 'dbo.BookAuthor'

--4)Relationship between tables namely "Book" and "Orders"
--Adding new column in Book table
ALTER TABLE dbo.Book
ADD OrderId INT NOT NULL

--Adding foreign key
ALTER TABLE dbo.Book
ADD CONSTRAINT fk_OrderId FOREIGN KEY(OrderId) REFERENCES dbo.Orders(OrderId)


--DML STATEMENTS
--Inserting data into tables

--Inserting data into Publisher
INSERT INTO dbo.Publisher(PublisherId,PublisherName,DateOfBirth,State,City,Phone)
VALUES(1,'Raj','1960/12/23','Bihar','Patna',95876)

INSERT INTO dbo.Publisher(PublisherId,PublisherName,DateOfBirth,State,City,Phone)
VALUES(2,'Shivaji','1950/10/13','Maharashtra','Pune',96785)

--Inserting data into Category
INSERT INTO dbo.Category(CategoryId,CategoryName,Description)
VALUES(100,'History','World History')

INSERT INTO dbo.Category(CategoryId,CategoryName,Description)
VALUES(101,'Mythological','Indian')

INSERT INTO dbo.Category(CategoryId,CategoryName,Description)
VALUES(102,'Romantic','World')

INSERT INTO dbo.Category(CategoryId,CategoryName,Description)
VALUES(103,'Technical','Software')

--Inserting data into Orders
INSERT INTO dbo.Orders(OrderId,Date,Quantity,UnitPrice,ShippingAddress)
VALUES(1000,'2015/11/16',12,450,'Pune')

INSERT INTO dbo.Orders(OrderId,Date,Quantity,UnitPrice,ShippingAddress)
VALUES(1001,'2015/10/11',15,230,'Mumbai')

INSERT INTO dbo.Orders(OrderId,Date,Quantity,UnitPrice,ShippingAddress)
VALUES(1002,'2015/10/10',20,500,'Nashik')

--Inserting data into Author
INSERT INTO dbo.Author(AuthorId,AuthorName)
VALUES(500,'Shivaji Sawant')

INSERT INTO dbo.Author(AuthorId,AuthorName)
VALUES(501,'Balguruswami')

INSERT INTO dbo.Author(AuthorId,AuthorName)
VALUES(502,'P.L.Deshpande')

INSERT INTO dbo.Author(AuthorId,AuthorName)
VALUES(503,'Vishwas Patil')

--Inserting data into Book
INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId)
VALUES(10,'Panipat','Historical',100,2,1000)

INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId)
VALUES(11,'C++ Language','Technical',103,1,1002)

INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId)
VALUES(12,'Mrutunjay','Mythological',100,2,1000)

INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId)
VALUES(13,'Prem','Romantic',100,2,1000)

INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId)
VALUES(14,'Java Language','Technical',103,1,1000)

UPDATE dbo.Book SET Price = 450 WHERE BookId=10

UPDATE dbo.Book SET Price = 500 WHERE BookId=11

UPDATE dbo.Book SET Price = 450 WHERE BookId=12

UPDATE dbo.Book SET Price = 450 WHERE BookId=13

UPDATE dbo.Book SET Price = 450 WHERE BookId=14


--Inserting data into BookAuthor
INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(500,12)

INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(501,11)

INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(502,13)

INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(503,10)

INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(503,13)

INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(502,10)

INSERT INTO dbo.BookAuthor(AuthorId,BookId)
VALUES(501,14)

--2]SELECT STATEMENTS

--a. Get All the books written by specific author
SELECT Title FROM dbo.Book WHERE BookId IN
(SELECT BookId FROM dbo.BookAuthor WHERE AuthorId =
(SELECT AuthorId FROM dbo.Author WHERE AuthorName ='Vishwas Patil'))

--b. Get all the books written by specific author and published by 
--specific publisher belonging to �Technical� book Category
SELECT Title FROM dbo.Book WHERE BookId IN
(SELECT BookId FROM dbo.BookAuthor WHERE AuthorId IN
(SELECT AuthorId FROM dbo.Author WHERE AuthorName ='Balguruswami')
AND
CategoryId =(SELECT CategoryId FROM dbo.Category WHERE CategoryName ='Technical')
AND
PublisherId=(SELECT PublisherId FROM dbo.Publisher WHERE PublisherName='Raj'))

--c. Get total books published by each publisher
SELECT PublisherId,COUNT(BookId) AS #Books FROM dbo.Book GROUP BY(PublisherId)

--d. Get all the books for which the orders are placed.  
SELECT Title FROM dbo.Book WHERE BookId IN
(SELECT BookId FROM dbo.Book WHERE OrderId IS NOT NULL)


--3]STORED PROCEDURE

--a. Get All the books written by specific author 
CREATE PROCEDURE #BooksBySpecificAuthor @AuthorId INT
AS
SELECT Title FROM dbo.Book WHERE BookId IN
(SELECT BookId FROM dbo.BookAuthor WHERE AuthorId = @AuthorId)

EXECUTE #BooksBySpecificAuthor 501

--b. Get all the books written by specific author and published by 
--specific publisher belonging to �Technical� book Category
CREATE PROCEDURE BooksBySPAuthorPublisherCategory @AuthorId INT,@PublisherName CHAR,@CategoryName CHAR
AS
 SELECT Title FROM dbo.Book WHERE BookId IN
 (SELECT BookId FROM dbo.BookAuthor WHERE AuthorId = 
 (SELECT AuthorId FROM dbo.Author WHERE AuthorId = @AuthorId)
 AND
 PublisherId = (SELECT PublisherId FROM dbo.Publisher WHERE PublisherName = @PublisherName)
 AND
 CategoryId = (SELECT CategoryId FROM dbo.Category WHERE CategoryName = @CategoryName))

EXECUTE BooksBySPAuthorPublisherCategory 501,'Raj','Technical'

--c. Get total books published by each publisher
CREATE PROCEDURE BookByPublisher
AS
 SELECT PublisherId, COUNT(BookId) AS #Books FROM dbo.Book GROUP BY(PublisherId)

EXECUTE BookByPublisher

--d. Insert a particular book
CREATE PROCEDURE InsertBook @BookId INT,@Title CHAR(30),@Description CHAR(30),@CategoryId INT,@PublisherId INT,@OrderId INT
AS
BEGIN
	INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId)
	VALUES(@BookId,@Title,@Description,@CategoryId,@PublisherId,@OrderId)
END

EXECUTE InsertBook 15,'C Language','Technical',103,1,1000

SELECT * FROM dbo.Book WHERE BookId=15



--e.Update a Particular book by Id
CREATE PROCEDURE UpdateBook @BookId INT
AS
BEGIN
	UPDATE dbo.Book SET OrderId = 1002 WHERE BookID = @BookId
END

EXECUTE UpdateBook 15

SELECT * FROM dbo.Book WHERE BookId=15

--Delete a Particular book by Id
CREATE PROCEDURE DeleteBook @BookId INT
AS
BEGIN
	DELETE FROM dbo.Book WHERE BookId=@BookId
END

EXECUTE DeleteBook 15

SELECT * FROM dbo.Book WHERE BookId=15


--TRIGGERS

/*5. Let�s assume that we have a table name �Book_History� table. If a particular book is deleted 
 from the �Book� table, an entry with same book records to �Book_History� table must take place. 
 Automate this process using trigger.*/


 CREATE TABLE BookHistory
(
	BookId INT PRIMARY KEY NOT NULL,
	Title char(50) NOT NULL,
	Description char(50) NOT NULL,
	Price INT NULL
)

--Adding new column in BookHistory table
ALTER TABLE dbo.BookHistory
ADD CategoryId INT NOT NULL

--Adding new column in BookHistory table
ALTER TABLE dbo.BookHistory
ADD PublisherId INT NOT NULL

--Adding new column in BookHistory table
ALTER TABLE dbo.BookHistory
ADD OrderId INT NOT NULL


sp_help 'dbo.BookHistory'

/*CREATING TRIGGER*/

CREATE TRIGGER TGR_BookHistory
ON dbo.Book
AFTER DELETE
AS
BEGIN
	INSERT INTO dbo.BookHistory SELECT * FROM DELETED
END

DELETE FROM dbo.Book WHERE BookId = 12

SELECT * FROM dbo.BookHistory


/*6. The �Book� table got an attribute �Price�. Let�s assume that we have a business requirement 
where we must ensure that the �Price� should not be less than 1. If any insert or update statement
 tries to make the �Price� less than 1, the SQL Server must terminate such insert or update 
 statements. Write an appropriate trigger to implement the business requirement. */

 
 CREATE TRIGGER TGR_ChechInsert
 ON dbo.Book
 AFTER INSERT, UPDATE
 AS
 BEGIN
	DECLARE @PR AS INT 
	SELECT @PR = Price FROM inserted
	IF (@PR < 1)
	BEGIN
		PRINT 'Price should not be less than 1'
		ROLLBACK
	END
 END

SELECT * FROM dbo.Book

INSERT INTO dbo.Book(BookId,Title,Description,CategoryId,PublisherId,OrderId,Price)
VALUES(16,'Javascript','Technical',103,2,1001,450)

UPDATE dbo.Book SET Price = 1 WHERE BookID = 15


/*7. Create a trigger on the table �Order� and add the following functionalities. When a new order 
is placed, it should check whether the required quantity is available in the �Book� table. If not, 
it should show appropriate message and the insert statement to �Order� table should be terminated. 
If the quantity in book table is sufficient, it should deduct the quantity ordered from the 
quantity in hand in the book table and update the quantity. */

ALTER TABLE dbo.Book 
ADD Quantity INT 

UPDATE dbo.Book SET Quantity = 6 

ALTER TABLE dbo.Orders
ADD BID INT

CREATE TRIGGER TGR_Order
ON dbo.Orders
AFTER INSERT
AS
BEGIN
	DECLARE @qnt INT
	DECLARE @qo INT
	DECLARE @bookId INT
	SELECT @qo = Quantity FROM inserted
	SELECT @bookId = BID FROM inserted
	SELECT @qnt = Quantity FROM dbo.Book WHERE BookId=@bookId
IF(@qo >@qnt)
BEGIN
	PRINT 'OUT OF STOCK'
	ROLLBACK
	END
ELSE
	BEGIN
		UPDATE dbo.Book SET Quantity = @qnt - @qo WHERE BookId=@bookId
	END
END

SELECT * FROM Orders

INSERT INTO dbo.Orders(OrderId,Date,Quantity,UnitPrice,ShippingAddress)
VALUES(1003,'2015/09/16',3,230,'Pune')

INSERT INTO dbo.Orders(OrderId,Date,Quantity,UnitPrice,ShippingAddress)
VALUES(1004,'2015/09/16',8,230,'Mumbai')