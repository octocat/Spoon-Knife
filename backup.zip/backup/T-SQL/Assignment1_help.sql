/* --------------------------------- ASSIGNMENT 1 -----------------------------------------*/

/*CREATING A DATABASE NAMED BOOKSTORE*/

CREATE DATABASE BookStoreDB

USE BookStoreDB

/*CREATING TABLE AUTHOR*/

CREATE TABLE Author
(
	AuthorID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	AuthorName CHAR(30) NOT NULL,
	DateOfBirth DATE NOT NULL,
	AuthorState CHAR(15) NOT NULL,
	City CHAR(20) NOT NULL,
	Phone INT NOT NULL 
)

/*CREATING TABLE BOOK*/

CREATE TABLE Book
(
	BookID INT IDENTITY(1001,1) PRIMARY KEY NOT NULL,
	Title CHAR(30) NOT NULL,
	BookDescription CHAR(30) NULL,
	Price INT NOT NULL,
	ISBN BIGINT UNIQUE NOT NULL, 
	PublicationDate DATE NOT NULL,
	BookImage IMAGE NULL
)

ALTER TABLE Book 
ALTER COLUMN BookImage VARBINARY

/*CREATING TABLE PUBLISHER*/

CREATE TABLE Publisher
(
	PublisherID INT IDENTITY(2001,1) PRIMARY KEY NOT NULL,
	PublisherName CHAR(30) NOT NULL,
	DateOfBirth DATE NULL,	
	PubState CHAR(30) NOT NULL,
	PubCity CHAR(30) NOT NULL,
	Phone INT NOT NULL,
)

/*CREATING TABLE CATEGORY*/

CREATE TABLE Category
(
	CategoryID INT IDENTITY(3001,1) PRIMARY KEY NOT NULL,
	CategoryName CHAR(30) NOT NULL UNIQUE,
	CategoryDesc CHAR(30) NULL
)

/*CREATING TABLE BOOKORDER*/

CREATE TABLE BookOrder
(
	OrderID INT IDENTITY(4001,1) PRIMARY KEY NOT NULL,
	OrderDate DATE NOT NULL,
	Quantity INT NULL DEFAULT(1),
	UnitPrice INT NOT NULL,
	ShippingAddress CHAR(60) NOT NULL
)

/*CREATING A JUNCTION TABLE*/

CREATE TABLE JunctionTable
(
	AID INT NULL,
	BID INT NULL,
	PID INT NULL,
	CID INT NULL,
	OID INT NULL,
	CONSTRAINT FK_AuthorID FOREIGN KEY (AID) REFERENCES Author (AuthorID) ON UPDATE CASCADE ON DELETE SET NULL,
	CONSTRAINT FK_BookID FOREIGN KEY (BID) REFERENCES Book (BookID) ON UPDATE CASCADE ON DELETE SET NULL,
	CONSTRAINT FK_PublisherID FOREIGN KEY (PID) REFERENCES Publisher (PublisherID) ON UPDATE CASCADE ON DELETE SET NULL,
	CONSTRAINT FK_CategoryID FOREIGN KEY (CID) REFERENCES Category (CategoryID) ON UPDATE CASCADE ON DELETE SET NULL,
	CONSTRAINT FK_OrderID FOREIGN KEY (OID) REFERENCES BookOrder (OrderID) ON UPDATE CASCADE ON DELETE SET NULL
)

/*INSERTING VALUES IN AUTHOR*/

INSERT INTO Author VALUES
('Arvind Adiga', '1980/12/10', 'Punjab', 'Amritsar', 987654321)

INSERT INTO Author VALUES
('K Subramanyam', '1979/02/23', 'Tamil Nadu', 'Chennai', 987654312)

INSERT INTO Author VALUES
('Durjoy Dutta', '1983/09/16', 'West Bengal', 'Calcutta', 987653412)

INSERT INTO Author VALUES
('Ravinder Singh', '1981/05/01', 'Madhya Praesh', 'Indore', 978563412)


SELECT * FROM Author

/*INSERTING VALUES IN BOOK*/

INSERT INTO Book (Title, BookDescription, Price, ISBN, PublicationDate) VALUES 
('The White Tiger', 'Booker Prize winner', 1056, 9573618452834, '2008/04/22')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('Last Man In Tower', 999, 9537614852389, '2011/08/14')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('Last Man In Tower', 999, 9537614852389, '2011/08/14')

UPDATE Author SET AuthorName = 'Kiran Desai' WHERE AuthorID = 4

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('The Namesake', 1024, 9573681452, '2003/07/18')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('The Lowland', 986, 7865154983254, '2013/08/24')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('Train To Pakistan', 784, 8439561287, '1956/04/30')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('The Company Of Women', 1000, 8445963797, '1999/11/28')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('Delhi: A Novel', 1116, 8435971256, '1990/12/21')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('The Inheritance Of Loss', 1123, 5435971256, '1990/07/31')

INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('Hullabaloo In The Guava', 567, 8462570594, '1998/04/15')

UPDATE Book SET PublicationDate = '2006/07/31' WHERE BookID = 1010
SELECT * FROM Book

/*INSERTING VALUES IN PUBLISHER*/

INSERT INTO Publisher (PublisherName, PubState, PubCity, Phone) VALUES
('Roopa Publications', 'Punjab', 'Bhatinda', 8742569215)

INSERT INTO Publisher (PublisherName, PubState, PubCity, Phone) VALUES
('Murthi Publications', 'Tamil Nadu', 'Chennai', 7954684589)

INSERT INTO Publisher (PublisherName, PubState, PubCity, Phone) VALUES
('Shivaji Publications', 'Maharashtra', 'Nagpur', 8795846823)

SELECT * FROM Publisher

/*INSERTING VALUES IN CATEGORY*/

INSERT INTO Category (CategoryName) VALUES
('Thriller')

INSERT INTO Category (CategoryName) VALUES
('Technical')

INSERT INTO Category (CategoryName) VALUES
('Comic')

INSERT INTO Category (CategoryName) VALUES
('SciFi')

SELECT * FROM Category


/*INSERTING VALUES IN BOOKORDER*/

INSERT INTO BookOrder (OrderDate, Quantity, UnitPrice, ShippingAddress) VALUES
('2015/07/26', 3, 784, 'Malabar Hills, Mumbai')

INSERT INTO BookOrder (OrderDate, Quantity, UnitPrice, ShippingAddress) VALUES
('2015/10/14', 2, 1024, 'Kothrud, Pune')

INSERT INTO BookOrder (OrderDate, Quantity, UnitPrice, ShippingAddress) VALUES
('2015/05/22', 5, 1000, 'Rajwada, Indore')

INSERT INTO BookOrder (OrderDate, Quantity, UnitPrice, ShippingAddress) VALUES
('2015/11/11', 1, 1114, 'RK Puram, Hyderabad')

SELECT * FROM BookOrder
UPDATE BookOrder SET UnitPrice = 1123 WHERE OrderID = 4004

/*INSERTING VALUES IN JUNCTION TABLE*/

INSERT INTO JunctionTable (AID, BID, PID, CID) VALUES 
(1, 1001, 2002, 3003)

INSERT INTO JunctionTable (AID, BID, PID, CID) VALUES 
(2, 1001, 2002, 3003)

INSERT INTO JunctionTable (AID, BID, PID, CID) VALUES
(1, 1003, 2003, 3002)

INSERT INTO JunctionTable VALUES
(2, 1005, 2002, 3004, 4002)

INSERT INTO JunctionTable (AID, BID, PID, CID) VALUES
(2, 1006, 2004, 3002)

INSERT INTO JunctionTable VALUES
(3, 1007, 2003, 3001, 4001)

INSERT INTO JunctionTable VALUES
(3, 1008, 2002, 3003, 4003)

INSERT INTO JunctionTable (AID, BID, PID, CID) VALUES
(3, 1009, 2002, 3002)

INSERT INTO JunctionTable VALUES
(4, 1010, 2003, 3004, 4004)

INSERT INTO JunctionTable (AID, BID, PID, CID) VALUES
(4, 1012, 2004, 3002)

SELECT * FROM JunctionTable




/* ----------------------------------SELECT STATEMENTS -----------------------------------*/

/*3a. GET ALL THE BOOKS WRITTEN BY SPECIFIC AUTHOR*/

SELECT Title FROM Book WHERE BookID IN 
(SELECT BID FROM JunctionTable WHERE AID = 
(SELECT AuthorID FROM Author WHERE AuthorName = 'Khushwant Singh'))

/*3b. Get all the books written by specific author and published by specific publisher belonging to 
�Technical� book Category */

SELECT Title FROM Book WHERE BookID IN 
(SELECT BID FROM JunctionTable WHERE CID IN 
(SELECT CategoryID FROM Category WHERE CategoryName = 'Technical') 
 AND 
 AID = (SELECT AuthorID FROM Author WHERE AuthorName = 'Kiran Desai') 
 AND 
 PID = (SELECT PublisherID FROM Publisher WHERE PublisherName = 'Shivaji Publications') )

 
 /*3c. Get total books published by each publisher. */

SELECT PID, COUNT(BID) AS Books FROM JunctionTable GROUP BY (PID)

 /*3d. Get all the books for which the orders are placed. */

 SELECT Title FROM Book WHERE BookID IN 
 (SELECT BID FROM JunctionTable WHERE OID IS NOT NULL)



/* ------------------------------------STORED PROCEDURES -----------------------------------*/

/*4a. Get All the books written by specific author*/

CREATE PROCEDURE PBooksBySpecificAuthor @AuthorID INT
AS
SELECT Title FROM Book
WHERE BookID IN
(SELECT BID FROM JunctionTable WHERE AID = @AuthorID)

EXECUTE PBooksBySpecificAuthor 3

/*4b. Get all the books written by specific author and published by specific publisher belonging 
to �Technical� book Category*/

CREATE PROCEDURE PSpecificBooks @CategoryID INT, @AuthorID INT, @PublisherID INT
AS
SELECT Title FROM Book 
WHERE BookID IN
(SELECT BID FROM JunctionTable WHERE 
CID  = @CategoryID
 AND 
 AID = @AuthorID
 AND 
 PID = @PublisherID) 

EXECUTE PSpecificBooks 3002, 4, 2004

/*4c. Get total books published by each publisher. */

CREATE PROCEDURE PTotalBooks
AS
SELECT J.PID, COUNT(J.BID) AS Books FROM Publisher P JOIN  JunctionTable J ON
 P.PublisherID = J.PID GROUP BY (PID)

 EXECUTE PTotalBooks

 /*4d. Insert a particular book */

 CREATE PROCEDURE PInsertBook @Title CHAR(30), @Price INT, @ISBN BIGINT, @PublicationDate DATE
 AS
 BEGIN
	INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES
	(@Title, @Price, @ISBN, @PublicationDate)
 END

 EXECUTE PInsertBook 'Between The Assassinations', 890, 8468724493158, '2008/11/01'

 SELECT * FROM Book

 /*4e. Update a particular book by id */

 CREATE PROCEDURE PUpdateBook @BookID INT
 AS
 BEGIN
	UPDATE Book SET Price = 1000 WHERE BookID = @BookID
 END

 EXECUTE PUpdateBook 1005
 SELECT * FROM Book
 /*4f. Delete a particular book by id */

 CREATE PROCEDURE PDeleteBook @BookID INT
 AS
 BEGIN
	DELETE FROM Book WHERE BookID = @BookID
 END

 EXECUTE PDeleteBook 1013

 
 
 /* -----------------------------------------TRIGGERS---------------------------------------*/


 /*5. Let�s assume that we have a table name �Book_History� table. If a particular book is deleted 
 from the �Book� table, an entry with same book records to �Book_History� table must take place. 
 Automate this process using trigger.*/

/*CREATING TABLE BOOKHISTORY*/

 CREATE TABLE BookHistory
(
	BookID INT PRIMARY KEY NOT NULL,
	Title CHAR(30) NOT NULL,
	BookDescription CHAR(30) NULL,
	Price INT NOT NULL,
	ISBN BIGINT UNIQUE NOT NULL, 
	PublicationDate DATE NOT NULL,
	BookImage VARBINARY
)

SELECT * FROM BookHistory

/*CREATING TRIGGER*/

CREATE TRIGGER TRG_BookHistory
ON Book 
AFTER DELETE 
AS
BEGIN
	INSERT INTO BookHistory SELECT * FROM DELETED
END

DELETE FROM Book WHERE BookID = 1009

SELECT * FROM BookHistory


/*6. The �Book� table got an attribute �Price�. Let�s assume that we have a business requirement 
where we must ensure that the �Price� should not be less than 1. If any insert or update statement
 tries to make the �Price� less than 1, the SQL Server must terminate such insert or update 
 statements. Write an appropriate trigger to implement the business requirement. */

 CREATE TRIGGER TRG_ChechInsert
 ON Book
 AFTER INSERT, UPDATE
 AS
 BEGIN
	DECLARE @PR AS INT 
	SELECT @PR = price FROM inserted
	IF (@PR < 1)
	BEGIN
		PRINT 'Price should not be less than 1'
		ROLLBACK
	END
 END

SELECT * FROM Book

 INSERT INTO Book (Title, Price, ISBN, PublicationDate) VALUES 
('Delhi', 1, 8753917756, '1990/12/12')

UPDATE Book SET Price = 1 WHERE BookID = 1014

/*7. Create a trigger on the table �Order� and add the following functionalities. When a new order 
is placed, it should check whether the required quantity is available in the �Book� table. If not, 
it should show appropriate message and the insert statement to �Order� table should be terminated. 
If the quantity in book table is sufficient, it should deduct the quantity ordered from the 
quantity in hand in the book table and update the quantity. */

ALTER TABLE Book 
ADD Quantity INT 

UPDATE Book SET Quantity = 5 

ALTER TABLE BookOrder
ADD BID INT

CREATE TRIGGER TRG_ORDER
ON BookOrder
AFTER INSERT
AS
BEGIN
	DECLARE @QNT AS INT
	DECLARE @QO AS INT
	declare @BoID AS INT
	SELECT @QO = Quantity FROM inserted
	SELECT @BoID= BID FROM inserted
	SELECT @QNT= Quantity FROM Book where BookID = @BoID
IF (@QO > @QNT)
	BEGIN
		PRINT 'OUT OF STOCK!'
		ROLLBACK
	END 
ELSE
	BEGIN
		UPDATE Book SET Quantity = @QNT - @QO WHERE BookID = @BoID
	END
END

insert into BookOrder VALUES
('2014/10/23', 3, 999, 'Kalyan, Mumbai', 1003)

insert into BookOrder VALUES
('2014/05/15', 8, 150, 'Arora Colony, Bhopal', 1014)


