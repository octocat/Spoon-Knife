--Section1 --Creating tables
create database bookstore

use bookstore

create table author
(
	authorid int identity(1,1) primary key not null,
	authorname char(40) not null,
	dateofbirth date null,
	state char(40) null,
	city char(40) null,
	phone int null
)

sp_help 'dbo.author'

--II. Publisher � PublisherId, PublisherName, DateOfBirth, State, City, Phone.  
create table publisher
(
	publisherid int identity(100,1) primary key not null,
	publishername char(40) not null,
	dateofbirth date null,
	state char(40) null,
	city char(40) null,
	phone int not null
)

sp_help 'publisher'

--III. Category � CategoryId, CategoryName, Description.  
create table category
(
	categoryid int identity(1000,1) primary key not null,
	categoryname char(40) not null,
	description char(40)
)

sp_help 'category'

--IV. Book � BookId,  Title, Description, Price, ISBN, PublicationDate, Image.  
create table book
(
	bookid int identity(10000,1) primary key not null,
	title char(40) not null,
	description char(40) null,
	price int not null,
	isbn int null,
	publicationdate date null,
	image char(40) null
)

sp_help 'book'

--V. Order � OrderId, Date, Quantity, UnitPrice, ShippingAddress. 
create table bookorder
(
	orderid int identity(500,1) primary key not null,
	orderdate date not null,
	quantity int not null,
	unitprice int not null,
	shippingaddress char(50) not null
)

sp_help 'bookorder'

--Section2  --Creating relationships
/*
A. A Book can have multiple authors. 
B. An Author can write more than one book.
i.e.many to many relationship,
so creating new table i.e. junction table
*/
create table junctionTable
(
	bookId int not null,
	authorId int not null,
	constraint fk_authorid foreign key(authorid) references author(authorId) ON UPDATE CASCADE ON DELETE cascade,
	constraint fk_bookid foreign key(bookid) references book(bookid) on update cascade on delete cascade,
	constraint pk_bookauthorid primary key(bookid,authorid)
)

sp_help 'junctionTable'

/*
C. A Book belongs to only one category. 
i.e. many to one relationship
Adding new column in Book table
*/
alter table book
add categoryid int not null

--Adding foreign key
alter table book
add constraint fk_categoryid foreign key(categoryid) references category(categoryid)

/*
D. A Book can be published by only one publishing house. 
i.e. many to one relationship
Adding new column in book table
*/
alter table book
add publisherid int not null

--adding foreign key
alter table book
add constraint fk_publisherid foreign key(publisherid) references publisher(publisherid)

--unique constraint to publisher table
alter table publisher
add unique(phone)

/*
E. An order can be placed for a single book but multiple quantities.
i.e. one to many relationship
Adding new column in book table
*/
alter table book
add orderid int null

--adding foreign key
alter table book
add constraint fk_orderid foreign key(orderid) references bookorder(orderid)

--order for multiple quantities
alter table bookorder
add check(quantity>1)


--DML STATEMENTS
--Inserting data into tables

--Inserting data into Publisher
insert into publisher(publishername,phone)
values('Raj Publications',96357)

insert into publisher(publishername,phone)
values('Shivaji Publications',96358)

--Inserting data into Category
insert into category(categoryname)
values('History')

insert into category(categoryname)
values('Mythological')

insert into category(categoryname)
values('Romantic')

insert into category(categoryname)
values('Technical')

--Inserting data into BookOrder
insert into bookorder(orderdate,quantity,unitprice,shippingaddress)
values('2015/11/16',12,450,'Pune')

insert into bookorder(orderdate,quantity,unitprice,shippingaddress)
values('2015/10/11',15,230,'Mumbai')

insert into bookorder(orderdate,quantity,unitprice,shippingaddress)
values('2015/10/10',20,500,'Nashik')

--Inserting data into Author
insert into author(authorname)
values('Shivaji Sawant')

insert into author(authorname)
values('Balguruswami')

insert into author(authorname)
values('P.L.Deshpande')

insert into author(authorname)
values('Vishwas Patil')

--Inserting data into Book
insert into book(title,price,categoryid,publisherid,orderid)
values('Panipat',450,1000,101,500)

insert into book(title,price,categoryid,publisherid,orderid)
values('C++ Language',500,1003,100,502)

insert into book(title,price,categoryid,publisherid,orderid)
values('Mrutunjay',450,1001,101,502)

insert into book(title,price,categoryid,publisherid)
values('Prem',230,1002,101)

insert into book(title,price,categoryid,publisherid,orderid)
values('Java Language',500,1003,100,502)

--inserting data into junctionTable
insert into junctionTable(authorId,bookId)
values(1,10002)

insert into junctionTable(authorId,bookId)
values(2,10001)

insert into junctionTable(authorId,bookId)
values(2,10004)

insert into junctionTable(authorId,bookId)
values(3,10003)

insert into junctionTable(authorId,bookId)
values(4,10000)

insert into junctionTable(authorId,bookId)
values(4,10003)

--Section3 --SELECT STATEMENTS
--a. Get All the books written by specific author
select title as BookTitle from book where bookid in
(select bookid from junctionTable where authorId =
(select authorId from author where authorname = 'Balguruswami'))

--b. Get all the books written by specific author and published by 
--specific publisher belonging to �Technical� book Category
select title as BookTile from book where bookid in
(select bookid from junctionTable where categoryid in
(select categoryid from category where categoryname = 'technical')
and
authorId =(select authorId from author where authorname = 'Balguruswami')
and
publisherid = (select publisherid from publisher where publishername = 'Raj Publications'))

--c. Get total books published by each publisher
select publisherid, count(bookid) as #books from book group by(publisherid)

--d. Get all the books for which the orders are placed.
select title as BookTile from book where orderid is not null

--Section4 --STORED PROCEDURE
--a. Get All the books written by specific author 
create procedure BooksbySpecificAuthor
@authorid int
as
select title from book where bookid in
(select bookid from junctionTable where authorId= @authorid)

execute BooksbySpecificAuthor 3

--b. Get all the books written by specific author and published by 
--specific publisher belonging to �Technical� book Category
create procedure BooksBySpecAuthorSpecPublisherSpecCategory
@authorid int, @publisherid int, @categoryName char(15)
as
select Title from book where bookid in
(select bookid from junctionTable where authorId = @authorid 
and
publisherid=@publisherid 
and 
categoryid in(select categoryid from category where categoryname=@categoryName))

execute BooksBySpecAuthorSpecPublisherSpecCategory 2, 100, 'Technical'

--c. Get total books published by each publisher
create procedure #BooksbyEachPublisher
as
select publisherid, count(bookid) as #Books from book group by(publisherid)

execute #BooksbyEachPublisher

--d. Insert a particular book
create procedure InserBook
@title char(50), @price int, @categoryid int, @publisherid int
as
insert into book(title,price,categoryid,publisherid)
values(@title, @price, @categoryid, @publisherid)

execute InserBook 'Radheya',450,1001,100

--e.Update a Particular book by Id
create procedure UpdateBook
@bookid int, @orderid int
as
update book 
set orderid=@orderid 
where bookid=@bookid

execute UpdateBook 10005,502

--f.Delete a Particular book by Id
create procedure DeleteBook
@bookid int
as
delete from book where bookid=@bookid

execute DeleteBook 10005

--Section5 --TRIGGERS

/*5. Let�s assume that we have a table name �Book_History� table. If a particular book is deleted 
 from the �Book� table, an entry with same book records to �Book_History� table must take place. 
 Automate this process using trigger.*/
 create table Book_History
 (
	bookid int primary key not null,
	title char(40) not null,
	description char(40) null,
	price int not null,
	isbn int null,
	publicationdate date null,
	image char(40) null
 )
 --drop table Book_History
 --adding column to Book_History table
 alter table Book_History
 add categoryid int not null

 --adding column to Book_History table
 alter table Book_History
 add publisherid int not null

 --adding column to Book_History table
 alter table Book_History
 add orderid int null

 --creating trigger on Book table
 alter trigger BookHistoryTgr
 on book
 after delete
 as
 begin
	insert into book_history select * from deleted
 end
 
 --invoking trigger
 delete from book where bookid=10000
 
 select * from book_history
 --not working

 /*6. The �Book� table got an attribute �Price�. Let�s assume that we have a business requirement 
where we must ensure that the �Price� should not be less than 1. If any insert or update statement
 tries to make the �Price� less than 1, the SQL Server must terminate such insert or update 
 statements. Write an appropriate trigger to implement the business requirement. */
 alter trigger checkTgr
 on book
 after insert, update
 as
 begin
	declare @price int
	select @price=price from inserted
	if(@price<1)
	begin
		print 'Price should not be less than 1'
		rollback
	end
 end
 
 insert into book(title,price,categoryid,publisherid)
 values('History of India',0,1000,101)

 update book set price = 0 where bookid=10003


 /*7. Create a trigger on the table �Order� and add the following functionalities. When a new order 
is placed, it should check whether the required quantity is available in the �Book� table. If not, 
it should show appropriate message and the insert statement to �Order� table should be terminated. 
If the quantity in book table is sufficient, it should deduct the quantity ordered from the 
quantity in hand in the book table and update the quantity. */

ALTER TABLE Book 
ADD Quantity INT 

UPDATE Book SET Quantity = 5

create trigger orderTgr
on bookorder
after insert
as
begin
	declare @orderqnt int
	declare @stockqnt int
	select @orderqnt=quantity from inserted
	select @stockqnt=quantity from book where bookid=(select bookid from inserted)
	if(@orderqnt<@stockqnt)
		begin
			update book set quantity=@stockqnt-@orderqnt where bookid=(select bookid from inserted)
		end
	else
		begin
			print 'out of stock'
			rollback
		end
end

insert into bookorder(orderdate,quantity,unitprice,shippingaddress)
values('2015/11/10',3,450,'Pune')

insert into bookorder(orderdate,quantity,unitprice,shippingaddress)
values('2015/11/13',8,230,'Mumbai')