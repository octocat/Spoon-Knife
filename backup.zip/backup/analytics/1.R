##DECISION TREE
#rm(list=ls())
# R code to import data
datasets <- read.csv("dataset.csv", header <- TRUE, sep <- ",")

# create test/train data sets
library(caret)
inTrain <- createDataPartition(y=datasets$riskType, p=0.7, list=FALSE)
training <- datasets[inTrain,]
testing <- datasets[-inTrain,]

# # fit classification tree as a model
# modFit <- train(riskType ~ ., method="rpart", data=training)
# # print the classification tree
# print(modFit$finalModel)
# rattle::fancyRpartPlot(modFit$finalModel)


# fit classification tree as a model
modFit <- train(riskType ~ ., method="rf", data=training, prox=TRUE)
# print the classification tree
print(modFit$finalModel)
getTree(modFit$finalModel, k=1)


# predict outcome for test data set using the random forest model
pred <- predict(modFit,testing)
# logic value for whether or not the rf algorithm predicted correctly
testing$predRight <- pred==testing$riskType
# tabulate results
a <- table(pred,testing$riskType)
a
library(psych)
Accuracy <- tr(a) / nrow(testing)
Accuracy


# plot data points with the incorrect classification highlighted
qplot(Hlos, ICD_Class, colour=predRight,data=testing,main="newdata Predictions")

