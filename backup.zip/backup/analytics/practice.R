##DECISION TREE

# R code to import data
datasets <- read.csv("dataset.csv", header <- TRUE, sep <- ",")

# create test/train data sets
library(caret)
inTrain <- createDataPartition(y=datasets$riskType, p=0.7, list=FALSE)

training <- datasets[inTrain,]
testing <- datasets[-inTrain,]

# fit classification tree as a model
modFit <- train(riskType ~ ., method="rpart", data=training)
# print the classification tree
print(modFit$finalModel)
rattle::fancyRpartPlot(modFit$finalModel)



##RANDOM FOREST CLASSIFICATION PLOT
names(datasets)
library(randomForest)
datasets.rf <- randomForest::randomForest(datasets[,-5], datasets[,5], prox=TRUE)
datasets.rf
datasets.p <- randomForest::classCenter(datasets[,-5], datasets[,5], datasets.rf$prox)
datasets.p

plot(datasets[,2], datasets[,4], pch=21, xlab=names(datasets)[2], ylab=names(datasets)[4],
     bg=c("green", "red")[as.numeric(factor(datasets$riskType))],
     main="Medical Data with Prototypes")
     legend("topright", pch = 1, col = c("green", "red"), legend = c("No Readmission", "Readmission"))
points(datasets.p[,2], datasets.p[,4], pch=21, cex=2, bg=c("green", "red"))


#Finding Accuracy
x<-datasets.rf$confusion
z<-x[,-3]
library(psych)
Accuracy <- tr(z) / nrow(datasets)
Accuracy
