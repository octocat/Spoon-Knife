x <- vector("numeric", length <- 10)
x


m <- matrix(1:6, nrow <- 2, ncol <- 3)
m
dim(m)

n <- matrix(1:6, nrow <- 2, ncol <- 3, byrow <- T)
n

l <- 1:6
dim(l) <- c(2, 3)
l

x <- 1:3
y <- 10:12
cbind(x, y)
rbind(x, y)

z <- data.frame(foo <- 1:4, bar <- c(T, F, T, T))
z

a <- matrix(1:4, nrow <- 2, ncol <- 2)
dimnames(a) <- list(c("a","b"),c("p","q"))
a