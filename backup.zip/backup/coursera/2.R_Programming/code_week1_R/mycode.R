first <- function() {
  x <- rnorm(100)
  mean(x)
}

second <- function(x) {
  x <- rnorm(x)
}

print(second(4))
