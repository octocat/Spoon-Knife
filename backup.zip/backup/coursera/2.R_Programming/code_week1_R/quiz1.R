x <- 4
class(x)

x <- c(4, "a", TRUE)
class(x)

x <- 1:4
y <- 2:3
z <- x + y
z
class(z)

x <- c(3, 5, 1, 10, 12, 6)
x[x %in% 1:5] <- 0
x[x < 6] = 0
x

mydata <- read.csv(file.choose(), header <- T, sep <- ",")
dim(mydata)
colnames(mydata)

head(mydata, n <- 2)

tail(mydata, n <- 2)

x <- mydata$Ozone[47]
x

x <- sum(is.na(mydata$Ozone))
x

x <- mean(mydata$Ozone, trim <- 0, na.rm <- T)
x

x <- subset(mydata, mydata$Ozone > 31 & mydata$Temp > 90)
x
y <- mean(x$Solar.R)
y

x <- subset(mydata, mydata$Month == 6)
x
y <- mean(x$Temp)
y

x <- subset(mydata, mydata$Month == 5)
x
y <- max(x$Ozone, na.rm = T)
y