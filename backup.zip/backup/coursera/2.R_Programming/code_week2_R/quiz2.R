x <- 1:10
if(x > 5) {
    x <- 0
}


make.power <- function(n) {
    pow <- function(x) {
        x^n
    }
    pow
}

c <- make.power(5)
c(3)
c(2)


y <- 10
f <- function(x) {
    y <- 2
    y^2 + g(x)
}

g <- function(x) {
    x * y
}

f(3)


y <- 10
f <- function(x) {
    y <- 2
    g <- function(x) {
        x * y
    }
    y^2 + g(x)
}

f(3)




f <- function(x) {
    g <- function(y) {
        y + z
    }
    z <- 4
    x + g(x)
}

z <- 10
f(3)

x <- 3L
x

x = NULL
y = NULL
d = 3L
z = cbind(x,d)
z

h <- function(x, y = NULL, d = 3L) {
    z <- cbind(x, d)
    if(!is.null(y))
        z <- z + y
    else
        z <- z + f
    g <- x + y / z
    if(d == 3L)
        return(g)
    g <- g + 10
    g
}

#rm(list=ls())
