x <- list(a = 1:5, b = rnorm(10))
lapply(x, mean) #  same as loop, but more compact, hence more efficient


y <- list(a = matrix(1:4, 2, 2), b = matrix(1:6, 3, 2))
y
lapply(y, function(elt) elt[, 1]) 

sapply(x, mean) #  Same as lapply, but gives simplified output

z <- matrix(rnorm(200), 20, 10)
# apply is used to apply function over margins of an array(on rows or columns of a matrix)
apply(z, 1, mean) 
apply(z, 2, mean)

mapply(rep, 1:4, 2:3)

printmessage <- function(x) {
        if(x > 0 ) {
              print("x is greater than zero")  
        } else {
              print("x is less than or equal to zero")        
        }
        #invisible(x)
}

x <- printmessage(2)
x
