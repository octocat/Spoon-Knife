library(datasets)
data("iris")
?iris
iris

vir <- subset(iris, iris$Species == "virginica")
vir
m <- mean(vir$Sepal.Length)
m

library(datasets)
data("mtcars")
?mtcars
mtcars
with(mtcars, tapply(mpg, cyl, mean))
?with
tapply(mtcars$cyl, mtcars$mpg, mean)

sapply(split(mtcars$mpg, mtcars$cyl), mean)

four_cyl <- subset(mtcars, mtcars$cyl == 4)
eight_cyl <- subset(mtcars, mtcars$cyl == 8)
?abs
x <- mean(four_cyl$hp)
y <- mean(eight_cyl$hp)
z <- x - y
abs(z)

debug(ls)
ls()
