best <- function(state, outcome) { 
        ## Read outcome data
        mydata <-read.csv("outcome-of-care-measures.csv", colClasses = "character")
        
        ## Check that state is valid
        if(!is.element(state, mydata$State)){
                stop("invalid state")
        }
        
        ## Check that outcome is valid
        ch <- outcome %in%  c("heart attack", "heart failure", "pneumonia")
        if(ch == FALSE){
                stop("invalid outcome")
        }
        
        ## qdapRegex package that has the TC (title case) function that does true title case:
        ## library(qdapRegex)
        ## Here outcome is in lower case, hence its case is changed to title case
        outcome <- TC(outcome)
        outcome <- paste("Hospital.30-Day.Death.(Mortality).Rates.from", outcome, sep = ".")
        #print(outcome)
        s <- subset(mydata, mydata$State == state)
        a <- as.data.frame(s)
        
        
        
        head(s$outcome)
        #print("hi")
        #minRate <- min(s[[outcome]])
        #print(minRate)
        #h <- s$Hospital.Name[which(minRate  == s[[outcome]])]
        #print(h)
        
        
        #s <- subset(mydata, min(mydata[outcome]))
        #print(s)
        
        ## Return hospital name in that state with lowest 30-day death rate
        
        
}

# source("best.R")
best("TX", "heart attack")
# [1] "CYPRESS FAIRBANKS MEDICAL CENTER"

best("TX", "heart failure")
# [1] "FORT DUNCAN MEDICAL CENTER"

best("MD", "heart attack")
# [1] "JOHNS HOPKINS HOSPITAL, THE"

best("MD", "pneumonia")
# [1] "GREATER BALTIMORE MEDICAL CENTER"

best("BB", "heart attack")
# Error in best("BB", "heart attack") : invalid state 

best("NY", "hert attack")
# Error in best("NY", "hert attack") : invalid outcome

