rankall <- function(outcome, num = "best") {
        ## 1.Read outcome data
        mydata <- read.csv("outcome-of-care-measures.csv", 
                           na.strings = "Not Available", 
                           stringsAsFactors = FALSE)
        
        
        ## Check that outcome is valid
        disease <- c("heart attack","heart failure","pneumonia")
        if(!(outcome %in% disease)){
                stop("Invalid Outcome")
        }
        
        if(!is.na(match(outcome,"heart attack"))) {
                col=11
        } else if(!is.na(match(outcome,"heart failure"))) {
                col=17
        } else {
                col=23  
        }
        
        ## 2.subset to three columns - hospital name, state, outcome
        takeData <- mydata[, c(2, 7, col)]
        
        ## 3.Subset to complete cases
        takeData <- na.omit(takeData)
        
        ## 4.Order by state then outcome then hospital name
        takeData <- takeData[order(takeData[2], takeData[3], takeData[1]), ]
        
        ## For each state, find the hospital of the given rank
        
        ## 5.Split on state
        splitData <- split(takeData, takeData[2])
        
        ## 6.Use lapply to get only the hospital names
        if(num == "best") {
                num = 1
                results_of_lapply <- lapply(splitData, function(x){x[num, 1]})
        } else if (num == "worst") {
                results_of_lapply <- lapply(splitData, function(x){x[nrow(x), 1]})
        } else {
                results_of_lapply <- lapply(splitData, function(x){x[num, 1]})
        }
        
        ## 7.Get hospital names with unlist(results_of_lapply)
        unlisted_values <- unlist(results_of_lapply)
        #print(unlisted_values)
        
        ## 8.Get states with names(results_of_lapply)
        list_names <- names(results_of_lapply)
        
        ## 9.Build the data frame with hospital names and states
        data.frame(hospital = unlisted_values, 
                   state = list_names, 
                   row.names = list_names )
        
        ## Return a data frame with the hospital names and the (abbreviated) state name
}

head(rankall("heart attack", 20), 10)
tail(rankall("pneumonia", "worst"), 3)
tail(rankall("heart failure"), 10)
