rankall <- function(outcome, num = "best") {
## Read outcome data

mydata <- read.csv("outcome-of-care-measures.csv", colClasses = "character")
mydata[mydata=="Not Available"]<- NA

## Check that state and outcome are valid

disease <- c("heart attack","heart failure","pneumonia")
if(!(outcome %in% disease))
stop("Invalid Outcome")

if(!is.na(match(outcome,"heart attack"))){
col=11}else if(!is.na(match(outcome,"heart failure"))){
col=17
}else
col=23

takeData <- mydata[, c(2,7,col)]
takeData <- takeData[complete.cases(takeData),]
takeData[,3] <-as.numeric(takeData[,3])
takeData <- takeData[order(takeData[,2],takeData[,3]), ]


colnames(takeData)=c("Name","State","Value")
u <- unique(takeData$State)



## For each state, find the hospital of the given rank
for(i in 1:length(u)){

}
tData
str(tData)
## Return a data frame with the hospital names and the
## (abbreviated) state name
}

outcome <- "heart attack"
num <- 20