rankhospital <- function(state, outcome, num) {
        ## Read outcome data
        mydata <- read.csv("outcome-of-care-measures.csv", na.strings = "Not Available", stringsAsFactors = FALSE)
        
        ## Check that state and outcome are valid
        if(!(state %in% mydata$State)){
                stop("Invalid State")
        }
        
        disease <- c("heart attack","heart failure","pneumonia")
        if(!(outcome %in% disease)){
                stop("Invalid Outcome")
        }
                
        if(!is.na(match(outcome,"heart attack"))){
                col=11
        } else if(!is.na(match(outcome,"heart failure"))){
                col=17
        } else{
                col=23  
        }
        
        ## Return hospital name in that state with lowest 30-day death
        #names(takeData) <- c("hospital", "state", "outcome")
        takeData <- mydata[, c(2, 7, col)]
        takeData <- na.omit(takeData)
        takeData <- subset(takeData, takeData$State == state)
        b <- takeData[order(takeData[3], takeData[1]), ]
        if(num == "best") {
                num = 1
        } else if (num == "worst") {
                num = nrow(b)
        }
        b <- b[num, ]
        b[, 1]

}

#source("rankhospital.R") 
rankhospital("TX", "heart failure", 4)
#[1] "DETAR HOSPITAL NAVARRO"
rankhospital("MD", "heart attack", "worst")
#[1] "HARFORD MEMORIAL HOSPITAL"
rankhospital("MN", "heart attack", 5000)
#[1] NA
