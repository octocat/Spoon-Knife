fileUrl <- "https://data.baltimorecity.gov/api/views/dz54-2aru/rows.csv?accessType=DOWNLOAD"
download.file(fileUrl,destfile="D://coursera_material/Getting & Cleaning Data/week1/cameras.csv",method="wininet")
list.files("D://coursera_material/Getting & Cleaning Data/week1/")
dateDownloaded <- date()
dateDownloaded
cameraData <- read.table("cameras.csv", sep = ",", header = TRUE)
head(cameraData)

cameraData <- read.csv("cameras.csv")

head(cameraData)

if(!file.exists("data")){dir.create("data")}
fileUrl <- "https://data.baltimorecity.gov/api/views/dz54-2aru/rows.xlsx?accessType=DOWNLOAD"
download.file(fileUrl,destfile="D://coursera_material/Getting & Cleaning Data/week1/data/cameras.xlsx",method="wininet")
dateDownloaded <- date()


library(XML)
fileUrl <- "http://www.w3schools.com/xml/simple.xml"
doc <- xmlTreeParse(fileUrl,useInternal=TRUE)
rootNode <- xmlRoot(doc)
xmlName(rootNode)
names(rootNode)
rootNode[[1]]
rootNode[[1]][[1]]
xmlSApply(rootNode,xmlValue)
xpathSApply(rootNode,"//name",xmlValue)
xpathSApply(rootNode,"//price",xmlValue)

## Extract content by attributes
fileUrl <- "http://espn.go.com/nfl/team/_/name/bal/baltimore-ravens"
doc <- htmlTreeParse(fileUrl,useInternal=TRUE)
scores <- xpathSApply(doc,"//li[@class='score']",xmlValue)
teams <- xpathSApply(doc,"//li[@class='team-name']",xmlValue)
scores
teams

## Reading data from JSON {jsonlite package}
library(jsonlite)
jsonData <- fromJSON("https://api.github.com/users/jtleek/repos")
names(jsonData)
names(jsonData$owner)
jsonData$owner$login

## Writing data frames to JSON
myjson <- toJSON(iris, pretty=TRUE)
cat(myjson)

## Convert back to JSON
iris2 <- fromJSON(myjson)
head(iris2)

## quiz1

#1
library(xlsx)
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FDATA.gov_NGAP.xlsx?accessType=DOWNLOAD"
download.file(fileUrl,destfile="D://coursera_material/Getting & Cleaning Data/week1/data/getdata_data_DATA.gov_NGAP.xlsx",method="wininet")
dat <- read.xlsx("week1/data/getdata_data_DATA.gov_NGAP.xlsx", rowIndex = 18:23, colIndex = 7:15, sheetIndex = 1)
dat
s <- sum(dat$Zip * dat$Ext, na.rm=T)
s

#2
library(XML)
fileUrl <- "http://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Frestaurants.xml"
doc <- xmlTreeParse(fileUrl,useInternal=TRUE)
rootNode <- xmlRoot(doc)
xmlName(rootNode)
names(rootNode)
rootNode[[1]]
rootNode[[1]][[1]]
xmlSApply(rootNode,xmlValue)
xpathSApply(rootNode,"//row[zipcode='21231']", xmlValue)

#3
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06pid.csv?accessType=DOWNLOAD"
download.file(fileUrl,destfile="week1/data/getdata_Fdata_Fss06pid.csv",method="wininet")
DT <- fread(input = "week1/data/getdata_Fdata_Fss06pid.csv")
DT
system.time(mean(DT$pwgtp15, by=DT$SEX))
system.time(mean(DT[DT$SEX==1,]$pwgtp15))
system.time(mean(DT[DT$SEX==2,]$pwgtp15))
system.time(sapply(split(DT$pwgtp15,DT$SEX),mean))
system.time(DT[,mean(pwgtp15),by=SEX]) ## faster user time
system.time(tapply(DT$pwgtp15,DT$SEX,mean))
rowMeans(DT)[DT$SEX==1]; rowMeans(DT)[DT$SEX==2] ## error

#4
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06hid.csv?accessType=DOWNLOAD"
download.file(fileUrl,destfile="week1/data/getdata_Fdata_Fss06pid.csv",method="wininet")
DT <- fread(input = "week1/data/getdata_Fdata_Fss06pid.csv")
DT$FES
str(DT$FES)
