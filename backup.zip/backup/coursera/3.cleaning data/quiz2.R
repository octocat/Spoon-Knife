#Q.1
url <- "https://api.github.com/users/jtleek/repos"

library(httpuv)
library(httr)

# 1. Find OAuth settings for github:
#    http://developer.github.com/v3/oauth/
oauth_endpoints("github")

# 2. To make your own application, register at at
#    https://github.com/settings/applications. Use any URL for the homepage URL
#    (http://github.com is fine) and  http://localhost:1410 as the callback url
#
#    Replace your key and secret below.
myapp <- oauth_app("github",
  key = "c09271f48c3bcef036e3",
  secret = "afb0cfd576f66979296ba49653a36f8296618c86")

# 3. Get OAuth credentials
github_token <- oauth2.0_token(oauth_endpoints("github"), myapp)

# 4. Use API
gtoken <- config(token = github_token)
req <- GET("https://api.github.com/rate_limit", gtoken)
stop_for_status(req)
content(req)

# OR:
req <- with_config(gtoken, GET("https://api.github.com/rate_limit"))
stop_for_status(req)
content(req)


#Q.2
library(sqldf)
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06pid.csv?accessType=DOWNLOAD"
download.file(fileUrl,destfile="week2/getdata_Fdata_Fss06pid.csv",method="wininet")
acs <- read.csv("week2/getdata_Fdata_Fss06pid.csv")
a <- sqldf("select pwgtp1 from acs where AGEP < 50")
a
a$AGEP

#Q.3
acs <- sqldf("select distinct AGEP from acs")
acs

#Q.4
help("nchar")
con <- url("http://biostat.jhsph.edu/~jleek/contact.html")
htmlCode <- readLines(con)
close(con)
str(htmlCode)
htmlCode <- as.character(htmlCode)
nchar(htmlCode[10])
nchar(htmlCode[20])
nchar(htmlCode[30])
nchar(htmlCode[100])

#Q.5
library(readr)
x <- read_fwf(
        file="https://d396qusza40orc.cloudfront.net/getdata%2Fwksst8110.for",   
        skip=4,
        fwf_widths(c(12, 7, 4, 9, 4, 9, 4, 9, 4)))
sum(x[, 4])
