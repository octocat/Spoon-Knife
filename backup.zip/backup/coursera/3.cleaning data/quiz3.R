#Q.1
mydata <- read.csv("getdata_data_ss06hid.csv")
agricultureLogical <- mydata$ACR == 3 & mydata$AGS == 6
head(which(agricultureLogical), 3)


#Q.2
?quantile
?readJPEG
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fjeff.jpg?raw=1"
download.file(fileUrl, destfile="getdata_jeff.jpg", method="auto")
library(jpeg)
img <- readJPEG(source = "getdata_jeff.jpg", native = TRUE)
quantile(x = img, probs = c(30, 80)/100)


#Q.4
a <- read.csv("getdata_data_GDP.csv", stringsAsFactors = FALSE)
b <- read.csv("getdata_data_EDSTATS_Country.csv", stringsAsFactors = FALSE)
m <- merge(a, b, by.x = 'X', by.y = 'CountryCode')

c <- subset(m, m$Income.Group == "High income: OECD")
c$Gross.domestic.product.2012 <- as.numeric(c$Gross.domestic.product.2012)
mean(c$Gross.domestic.product.2012)

d <- subset(m, m$Income.Group == "High income: nonOECD")
d$Gross.domestic.product.2012 <- as.numeric(d$Gross.domestic.product.2012)
mean(d$Gross.domestic.product.2012, na.rm = TRUE)


rm(list=ls())
#Q.3
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FGDP.csv?raw=1"
download.file(fileUrl, destfile="week3/getdata_data_GDP.csv", method="auto")
a <- read.csv("getdata_data_GDP.csv")
rowindex <- 5:194
a <- a[rowindex, ]
a$Gross.domestic.product.2012
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FEDSTATS_Country.csv?raw=1"
download.file(fileUrl, destfile="week4/getdata_data_EDSTATS_Country.csv", method="auto")
b <- read.csv("getdata_data_EDSTATS_Country.csv")
a$match <- match(a$X, b$CountryCode, nomatch = 0)
length(which(a$match != 0))
write.csv(x = a, file = "new.csv")
tail(a$X, n = 12)


#Q.5 not solved


