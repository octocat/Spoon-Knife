#Q.1 
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06hid.csv?raw=1"
download.file(fileUrl, destfile="week4/getdata_data_ss06hid.csv", method="auto")
mydata <- read.csv("week4/getdata_data_ss06hid.csv")
lst <- strsplit(names(mydata), "wgtp")
lst[123]


#Q.2
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FGDP.csv?raw=1"
download.file(fileUrl, destfile="week4/getdata_data_GDP.csv", method="auto")
mydata <- read.csv("week4/getdata_data_GDP.csv")
rowindex <- 5:194
a <- mydata[rowindex, ]
a$X.3 <- gsub(",", "", a$X.3)
b <- suppressWarnings(as.numeric(a$X.3))
mean(b, na.rm = TRUE)


#Q.3 
#grep("^United",countryNames), 3
mydata <- read.csv("week4/getdata_data_GDP.csv")
grep("^United", mydata$X.2)


#Q.4
fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FGDP.csv?raw=1"
download.file(fileUrl, destfile="week4/getdata_data_GDP.csv", method="auto")
gdp <- read.csv("week4/getdata_data_GDP.csv")
rowindex <- 5:194
gdp <- gdp[rowindex, ]

fileUrl <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FEDSTATS_Country.csv?raw=1"
download.file(fileUrl, destfile="week4/getdata_data_EDSTATS_Country.csv", method="auto")
ed <- read.csv("week4/getdata_data_EDSTATS_Country.csv")

m <- merge(gdp, ed, by.x = 'X', by.y = 'CountryCode')
a <- grepl("Fiscal year end: June", m$Special.Notes)
length(which(a))


#Q.5
library(quantmod)
amzn = getSymbols("AMZN",auto.assign=FALSE)
sampleTimes = index(amzn)

str(amzn)
length(grep("2012",sampleTimes))

df = data.frame(date=sampleTimes)
library(lubridate)
a <- year(df$date) == 2012 & wday(df$date, label=TRUE) == "Mon"
length(which(a))

