mydata <- read.table(file = "exdata_data_household_power_consumption/household_power_consumption.txt",
                     header = TRUE, sep = ";")

data_bk <- mydata
library(lubridate)
data_bk$Date <- dmy(mydata$Date)
data_bk$Date <- as.Date(data_bk$Date)
data_bk$dt <- paste(data_bk$Date, data_bk$Time, sep = " ")
data_bk$dtime <- as.POSIXct(data_bk$dt)
#data_bk$dtime <- dmy_hms(data_bk$dt)

actualData <- subset(data_bk, (data_bk$Date == "2007-02-01" | 
                                       data_bk$Date == "2007-02-02"))
#actualData$WDay <- wday(actualData$Date, label = TRUE)
actualData <- subset(actualData, (actualData$WDay == "Thurs" | 
                                        actualData$WDay == "Fri" |
                                        actualData$WDay == "Sat"))
f <- actualData$Global_active_power
actualData$Global_active_power <- as.numeric(levels(f))[f]
actualData <- subset(actualData, Global_active_power <= 6)

table(actualData$WDay)

library(dplyr)
groupData <- group_by(actualData, WDay)
groupData$WDay


plot(data_bk$dtime, data_bk$Global_active_power)

plot(groupData$WDay,groupData$Global_active_power,type="l")

ggplot(groupData, aes(WDay, Global_active_power))+geom_line(color="lightpink4", lwd=1)
