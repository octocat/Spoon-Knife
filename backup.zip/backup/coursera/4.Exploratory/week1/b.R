mydata <- read.table(file = "exdata_data_household_power_consumption/household_power_consumption.txt",
                     header = TRUE, sep = ";")

#data_bk <- mydata
library(lubridate)
mydata$Date <- dmy(mydata$Date)
mydata$Date <- as.Date(mydata$Date)
mydata$dt <- paste(mydata$Date, mydata$Time, sep = " ")
mydata$dtime <- as.POSIXct(mydata$dt)
#data_bk$dtime <- dmy_hms(data_bk$dt)

actualData <- subset(mydata, (mydata$Date == "2007-02-01" | 
                                      mydata$Date == "2007-02-02"))
#actualData$WDay <- wday(actualData$Date, label = TRUE)
# actualData <- subset(actualData, (actualData$WDay == "Thurs" | 
#                                           actualData$WDay == "Fri" |
#                                           actualData$WDay == "Sat"))
f <- actualData$Global_active_power
actualData$Global_active_power <- as.numeric(levels(f))[f]
actualData <- subset(actualData, Global_active_power <= 6)

#table(actualData$WDay)

# library(dplyr)
# groupData <- group_by(actualData, WDay)
# groupData$WDay


plot(actualData$dtime, actualData$Global_active_power, type="l")

#plot(groupData$WDay,groupData$Global_active_power,type="l")

#ggplot(groupData, aes(WDay, Global_active_power))+geom_line(color="lightpink4", lwd=1)
