NEI <- readRDS("summarySCC_PM25.rds")

#1.Have total emissions from PM2.5 decreased in the United States from 1999 to 2008?
library(dplyr)
grpData <- group_by(NEI, year)
tidData <- summarise(grpData, sum(Emissions))
plot(tidData$year, tidData$`sum(Emissions)`, 
     main = "Year-wise PM2.5 Emission", xaxt = "n",
     xlab = "Year",  ylab = "Total PM2.5 Emission" )
axis(1, at = c(1999, 2002, 2005, 2008), labels = c(1999, 2002, 2005, 2008))

## Copy my plot to a PNG file
dev.copy(png, file = "plot1.png")
## Don't forget to close the PNG device!
dev.off()
