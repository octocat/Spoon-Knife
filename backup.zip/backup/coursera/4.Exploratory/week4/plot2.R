# 2. Have total emissions from PM2.5 decreased in the 
#    Baltimore City, Maryland (fips == "24510") from 1999 to 2008? 

NEI <- readRDS("summarySCC_PM25.rds")
data <- subset(NEI, fips == "24510")
library(dplyr)
grpData <- group_by(data, year)
tidData <- summarise(grpData, sum(Emissions))
plot(tidData$year, tidData$`sum(Emissions)`, 
     main = "Year-wise PM2.5 Emission for Baltimore City", xaxt = "n",
     xlab = "Year",  ylab = "Total PM2.5 Emission" )
axis(1, at = c(1999, 2002, 2005, 2008), labels = c(1999, 2002, 2005, 2008))

## Copy my plot to a PNG file
dev.copy(png, file = "plot2.png")
## Don't forget to close the PNG device!
dev.off()
