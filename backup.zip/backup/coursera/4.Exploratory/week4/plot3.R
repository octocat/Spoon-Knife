# 3.Of the four types of sources indicated by the type 
# (point, nonpoint, onroad, nonroad) variable, which of these four sources 
# have seen decreases in emissions from 1999-2008 for Baltimore City? 
# Which have seen increases in emissions from 1999-2008? 

NEI <- readRDS("summarySCC_PM25.rds")
NEIdata <- subset(NEI, fips == "24510")
library(dplyr)
grpData <- group_by(NEIdata, type, year)
tidData <- summarise(grpData, sum(Emissions))
library(ggplot2)
qplot(x = year, y = `sum(Emissions)`, data = tidData, geom = c("point", "line"), 
      facets = . ~ type, main = "Year-wise PM2.5 Emission for each Type in Baltimore City",
      xlab = "Year", ylab = "Total PM2.5 Emission") + 
        scale_x_continuous(breaks=c(1999, 2002, 2005, 2008)) + 
        theme(axis.text.x=element_text(size=6))

## Copy my plot to a PNG file
dev.copy(png, file = "plot3.png")
## Don't forget to close the PNG device!
dev.off()
