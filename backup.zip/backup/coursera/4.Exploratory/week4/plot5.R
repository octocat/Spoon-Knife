# 5.How have emissions from motor vehicle sources changed from 
# 1999-2008 in Baltimore City?

NEI <- readRDS("summarySCC_PM25.rds")
SCC <- readRDS("Source_Classification_Code.rds")
NEIdata <- subset(NEI, fips == "24510")
subsetSccData <- subset(SCC, grepl(pattern = "Motor", x = Short.Name))
mergeData <- merge(x = NEIdata, y = subsetSccData, by = "SCC")
library(dplyr)
grpData <- group_by(mergeData, year)
tidData <- summarise(grpData, sum(Emissions))

plot(tidData$year, tidData$`sum(Emissions)`, 
     main = "Year-wise PM2.5 Emission from Motor Vehicle in Baltimore City", 
     xaxt = "n", xlab = "Year",  ylab = "Total PM2.5 Emission" )
axis(1, at = c(1999, 2002, 2005, 2008), labels = c(1999, 2002, 2005, 2008))

## Copy my plot to a PNG file
dev.copy(png, file = "plot5.png")
## Don't forget to close the PNG device!
dev.off()
