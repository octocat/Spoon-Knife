# 6.Compare emissions from motor vehicle sources in Baltimore City with emissions
# from motor vehicle sources in Los Angeles County, California (fips == "06037").
# Which city has seen greater changes over time in motor vehicle emissions?

NEI <- readRDS("summarySCC_PM25.rds")
SCC <- readRDS("Source_Classification_Code.rds")

baltimoredata <- subset(NEI, fips == "24510")
subsetSccData1 <- subset(SCC, grepl(pattern = "Motor", x = Short.Name))
mergeData1 <- merge(x = baltimoredata, y = subsetSccData1, by = "SCC")
library(dplyr)
grpData1 <- group_by(mergeData1, year)
tidData1 <- summarise(grpData1, sum(Emissions))

losAngelesData <- subset(NEI, fips == "06037")
subsetSccData2 <- subset(SCC, grepl(pattern = "Motor", x = Short.Name))
mergeData2 <- merge(x = losAngelesData, y = subsetSccData2, by = "SCC")
grpData2 <- group_by(mergeData2, year)
tidData2 <- summarise(grpData2, sum(Emissions))

par(mfrow = c(1, 2))
plot(tidData1$year, tidData1$`sum(Emissions)`, 
     main = "Baltimore City", 
     xaxt = "n", xlab = "Year",  ylab = "Total PM2.5 Emission" )
axis(1, at = c(1999, 2002, 2005, 2008), labels = c(1999, 2002, 2005, 2008))

plot(tidData2$year, tidData2$`sum(Emissions)`, 
     main = "Los Angeles", 
     xaxt = "n", xlab = "Year",  ylab = "Total PM2.5 Emission" )
axis(1, at = c(1999, 2002, 2005, 2008), labels = c(1999, 2002, 2005, 2008))

## Copy my plot to a PNG file
dev.copy(png, file = "plot6.png")
## Don't forget to close the PNG device!
dev.off()
