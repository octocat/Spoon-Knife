# What is mean total number of steps taken per day?
# 1. Make a histogram of the total number of steps taken each day

# unziping the activity.zip file
unzip("activity.zip")

# reading activity file
activityData <- read.csv("activity.csv")

# Finding sum no. of steps per day
StepsByDaySum <- tapply(activityData$steps, activityData$date, sum)

# Creating histogram
hist(StepsByDaySum, xlab="Total steps by day",ylab="Frequency (Days)",
     main="Histogram : Number of daily steps", breaks=20)

# Copy my plot to a PNG file
dev.copy(png, file = "figures/plot1.png")

# Don't forget to close the PNG device!
dev.off()

# 2.Calculate & report the mean and median total number of steps taken per day

# finding mean
StepsByDayMean <- mean(StepsByDaySum, na.rm = TRUE)
StepsByDayMean

# finding median
StepsByDayMedian <- median(StepsByDaySum, na.rm = TRUE)
StepsByDayMedian


# What is the average daily activity pattern
# 1.Make a time series plot (i.e. type = "l") of the 5-minute interval(x-axis)
# and the average number of steps taken, averaged across all days (y-axis)

# applying tapply with mean
StepsByIntervalAvg <- tapply(activityData$steps, activityData$interval, 
                             mean, na.rm = T)

# plotting graph
plot(StepsByIntervalAvg, type = "l", xlab="5 minute interval", 
     ylab="Average number of steps", 
     main="Average number of steps(by each 5 minute interval)")

# Copy my plot to a PNG file
dev.copy(png, file = "figures/plot2.png")

# Don't forget to close the PNG device!
dev.off()

# 2. Which 5-minute interval, on average across all the days in the dataset,
# contains the maximum number of steps

maxStepsInterval <- activityData$interval[which.max(StepsByIntervalAvg)]
maxStepsInterval


# Imputing missing values

# 1. Calculate and report the total number of missing values in the dataset 
# (i.e. the total number of rows with NAs)

NoOfRowsWithNA <- sum(is.na(activityData))
NoOfRowsWithNA

# 2. Devise a strategy for ???lling in all of the missing values in the dataset. 
# For example, you could use the mean/median for that day, or the mean for 
# that 5-minute interval, etc.

# For replacing missing values in the dataset, 
# we use mean for that 5-minute interval.


# 3. Create a new dataset that is equal to the original dataset but with the 
# missing data ???lled in.

newActivityData <- activityData 
StepsByInterval_Mean <- tapply(newActivityData$steps, newActivityData$interval, 
                               mean, na.rm = T)
newActivityData$steps[is.na(newActivityData$steps)] <- StepsByInterval_Mean

# 4. Make a histogram of the total number of steps taken each day and Calculate
# and report the mean and median total number of steps taken per day. Do
# these values differ from the estimates from the first part of the assignment?
# What is the impact of imputing missing data on the estimates of the total
# daily number of steps?

newStepsByDaySum <- tapply(newActivityData$steps, newActivityData$date, sum)

# plotting histogram
hist(newStepsByDaySum, xlab="Total steps by day",ylab="Frequency (Days)", 
     main="Histogram : Number of daily steps", breaks=20)

# Copy my plot to a PNG file
dev.copy(png, file = "figures/plot3.png")

# Don't forget to close the PNG device!
dev.off()

# finding mean
newStepsByDayMean <- mean(newStepsByDaySum)
newStepsByDayMean

# finding median
newStepsbyDayMedian <- median(newStepsByDaySum)
newStepsbyDayMedian

# It is observed that, the mean value is unchanged while median value is 
# different from the estimates from the first part of the assignment

# After imputing missing data, the estimates of the total daily number of 
# steps i.e. mean and median are observed to be same.


# Are there differences in activity patterns between weekdays and weekends?

# 1. Create a new factor variable in the dataset with two levels  weekday
# and weekend indicating whether a given date is a weekday or weekend day.

# changing datatype of date column
newActivityData$date <- as.Date(as.character(newActivityData$date, 
                                             format = "%Y%m%d"))
newActivityData$day <- weekdays(newActivityData$date)
newActivityData$day[newActivityData$day == "Saturday" | 
                    newActivityData$day == "Sunday"] <- "weekend"
newActivityData$day[newActivityData$day == "Monday" | 
                    newActivityData$day == "Tuesday" |
                    newActivityData$day == "Wednesday" |
                    newActivityData$day == "Thursday" |
                    newActivityData$day == "Friday"] <- "weekday"
newActivityData$day <- as.factor(newActivityData$day)

# 2. Make a panel plot containing a time series plot (i.e. type = "l") of 
# the 5-minute interval (x-axis) and the average number of steps taken, 
# averaged across all weekday days or weekend days (y-axis).

newActivityDataWeekday <- subset(newActivityData, day == "weekday")
newActivityDataWeekEndday <- subset(newActivityData, day == "weekend")

newStepsByIntervalMeanWeekday <- tapply(newActivityDataWeekday$steps, 
                                        newActivityDataWeekday$interval, mean)
newStepsByIntervalMeanWeekEndday <- tapply(newActivityDataWeekEndday$steps, 
                                        newActivityDataWeekEndday$interval, 
                                        mean)
par(mfrow = c(2, 1))
plot(newStepsByIntervalMeanWeekday, 
     type = "l", main = "Weekday", 
     xlab="5 minute interval", ylab="Average number of steps")
plot(newStepsByIntervalMeanWeekEndday, 
     type = "l", main = "Weekendday", 
     xlab="5 minute interval", ylab="Average number of steps")

# Copy my plot to a PNG file
dev.copy(png, file = "figures/plot4.png")

# Don't forget to close the PNG device!
dev.off()
