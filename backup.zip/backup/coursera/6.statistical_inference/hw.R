#hw3
#1
library(datasets)
data("mtcars")
a <- t.test(mtcars$mpg)
a
a$conf.int
# [1] 17.91768 22.26357
# attr(,"conf.level")
# [1] 0.95

#2
qt(p = 0.975, df = 8)*1/3

#3
data("mtcars")
m4 <- mtcars$mpg[mtcars$cyl == 4]
m6 <- mtcars$mpg[mtcars$cyl == 6]
a <- t.test(x = m4, y = m6, var.equal = TRUE)
a
round(a$conf.int, 1)


#hw4
#1 (page =3/14)
data("mtcars")
mn <- mean(mtcars$mpg)        
mn
s <- sd(mtcars$mpg)
s
z <- qnorm(0.05)
z

m0 <- mn - z * s/sqrt(nrow(mtcars))
m0
#OR
m0 <- mn + qnorm(0.95) * s/sqrt(nrow(mtcars))
m0

#2 (page =4/14)
data("mtcars")
m4 <- mtcars$mpg[mtcars$cyl == 4]
m6 <- mtcars$mpg[mtcars$cyl == 6]
a <- t.test(x = m4, y = m6, alternative = "t", var.equal = FALSE)
a

#3 (page = 6/14)
round(pbinom(q = 54, size = 100, prob = 0.5, lower.tail = FALSE), 4)

#4 (page = 7/14)
ppois(q = 15800-1, lambda = 520 * 30, lower.tail = FALSE)

#5 (page = 13/14)
data("mtcars")
mpg6 <- mtcars$mpg[mtcars$cyl == 6]
mpg8 <- mtcars$mpg[mtcars$cyl == 8]
a <- t.test(x = mpg8, y = mpg6, var.equal = TRUE)
round(a$p.value, 3)
n8 <- length(mpg8)
n6 <- length(mpg6)
s8 <- sd(mpg8)
s6 <- sd(mpg6)
m8 <- mean(mpg8)
m6 <- mean(mpg6)
mixprob <- (n8 - 1)/(n8 + n6 - 2)
mixprob
s <- sqrt(mixprob * s8^2 + (1 - mixprob) * s6^2)
s
z <- (m8 - m6)/(s * sqrt((1/n8) + (1/n6)))
z
pz <- pnorm(-abs(z))
pz
