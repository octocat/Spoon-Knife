# quiz1
# Q.2) 
help("qunif")
qunif(p = 0.75, min = 0, max = 1)
# [1] 0.75

# quiz2
# Q.2) 
pnorm(q = 70, mean = 80, sd = 10)        
# [1] 0.1586553

# Q.3)
qnorm(p = .95, mean = 1100, sd = 75)
# [1] 1223.364

# Q.4)
qnorm(p = .95, mean = 1100, sd = 75/sqrt(100))
# [1] 1112.336

# Q.5)
# You will have 32 possible outcomes 32=2^5.
# 5 heads - 1/32 
# 4 heads - 5/32
# 1+5/32
# 0.1875

# Q.6)
# https://people.richland.edu/james/lecture/m170/ch07-clt.html
# If the population is not normally distributed, but the sample size is 
# sufficiently large, then the sample means will have an approximately 
# normal distribution. Some books define sufficiently large as at least 30 
# and others as at least 31


# Q.7)
qnorm(p = .5, mean = .5, sd = 1/(12*sqrt(1000)))
# 0.5

# Q.8)
ppois(q = 10, lambda = 5*3)
# [1] 0.1184644

#quiz3
#Q.1
mn <- 1100
n <- 9
std <- 30
alpha <- 0.95
confInt <- mn + c(-1, 1) * qt(alpha, n-1) * (std / sqrt(n))
round(confInt)
