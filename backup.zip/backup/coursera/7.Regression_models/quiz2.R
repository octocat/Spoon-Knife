# Q.1-correct
x <- c(0.61, 0.93, 0.83, 0.35, 0.54, 0.16, 0.91, 0.62, 0.62)
y <- c(0.67, 0.84, 0.6, 0.18, 0.85, 0.47, 1.1, 0.65, 0.36)
fit <- lm(y~x)
summary(fit)
# 0.053


# Q.2 same data as Q.1-correct
# 0.223


# Q.3
x<-mtcars$wt
y<-mtcars$mpg
fit<-lm(y ~ x)
predict(fit,data.frame(x=mean(x)), interval="confidence")
# fit      lwr      upr
# 20.09062 18.99098 21.19027


# Q.4
help("mtcars")
# Weight (1000 lbs)
# The estimated expected change in mpg per 1,000 lb increase in weight.


# Q.5 same data as Q.3 - not solved
x<-mtcars$wt
y<-mtcars$mpg
fit<-lm(y ~ x)
predict(fit,data.frame(x=3), interval="prediction")


# Q.6 same data as Q.5-correct
fit <- lm(mpg~I(wt/2), mtcars)
summary(fit)
# store results in matrix
sumCoef <- summary(fit)$coefficients
# print out confidence interval for beta1 in 1/10 units
(sumCoef[2, 1] + c(-1, 1) * qt(.975, df = fit$df) * sumCoef[2, 2])
# -12.97262


# Q.7
summary(fit)$coefficients
##             Estimate Std. Error t value  Pr(>|t|)
## (Intercept)   37.285     1.8776  19.858 8.242e-19
## x             -5.344     0.5591  -9.559 1.294e-10
fit3<-lm(y~I(x/100))
summary(fit3)$coefficients
##             Estimate Std. Error t value  Pr(>|t|)
## (Intercept)    37.29      1.878  19.858 8.242e-19
## I(x/100)     -534.45     55.910  -9.559 1.294e-10


# Q.8
c<-5
cf1<-summary(fit)$coefficients
cf1
##             Estimate Std. Error t value  Pr(>|t|)
## (Intercept)   37.285     1.8776  19.858 8.242e-19
## x             -5.344     0.5591  -9.559 1.294e-10
fit4<-lm(y~I(x+c)) # add some constant c
cf2<-summary(fit4)$coefficients
cf2
##             Estimate Std. Error t value  Pr(>|t|)
## (Intercept)   64.007     4.6257  13.837 1.467e-14
## I(x + c)      -5.344     0.5591  -9.559 1.294e-10
b0<-cf1[1,1]
b1<-cf1[2,1]
c(b0,b1)
## [1] 37.285 -5.344
b0 - c*b1
## [1] 64.01


# Q.9
fit5<-lm(y ~ 1) #model with only intercept
fit6<-lm(y ~ x - 1) # model with only slope
plot(x,y)

abline(fit,col="red")
abline(fit5,col="blue")
abline(fit6,col="green")

anova(fit)
anova(fit5)
278/1126
# 0.2468917


# Q.10
# If an intercept is included, then residuals will sum to 0
