# Q.1
data("mtcars")
fit <- lm(mtcars$mpg ~ factor(mtcars$cyl)+mtcars$wt)
summary(fit)$coef
# ans:- -6.0709

# Q.2
fit1 <- lm(mtcars$mpg ~ factor(mtcars$cyl)+mtcars$wt)
summary(fit1)$coef

fit2 <- lm(mtcars$mpg ~ factor(mtcars$cyl))
summary(fit2)$coef
# ans:-Holding weight constant, cylinder appears to have 
# less of an impact on mpg than if weight is disregarded.

# Q.3
fit1 <- lm(mpg ~ factor(cyl) + wt, data = mtcars)
summary(fit1)$coef
fit2 <- lm(mpg ~ factor(cyl) * wt, data = mtcars)
summary(fit2)$coef
anova(fit1, fit2)
# The P-value is larger than 0.05. So, according to our criterion, we would fail 
# to reject, which suggests that the interaction terms may not be necessary.

# Q.4
fit <- lm(mpg ~ wt + factor(cyl), data = mtcars)
coef(fit)
summary(fit)$coef
fit1 <- lm(mpg ~ I(wt * 0.5) + factor(cyl), data = mtcars)
coef(fit1)
summary(fit1)$coef
# The estimated expected change in MPG per half ton increase in 
# weight for for a specific number of cylinders (4, 6, 8).

# Q.5
x <- c(0.586, 0.166, -0.042, -0.614, 11.72)
y <- c(0.549, -0.026, -0.127, -0.751, 1.344)
a <- hatvalues(lm(y~x))
a
# ans:- 0.9946

# Q.6- wrong
x <- c(0.586, 0.166, -0.042, -0.614, 11.72)
y <- c(0.549, -0.026, -0.127, -0.751, 1.344)
a <- hatvalues(lm(y~x))
a
b <- dfbeta(lm(y~x))
b
# ans:- 0.673---- -0.378 wrong

# Q.7
# ans :- It is possible for the coefficient to reverse sign after adjustment. 
# For example, it can be strongly significant and positive before adjustment 
# and strongly significant and negative after adjustment.