# Q.1-- incorrect
library(MASS)
data("shuttle")
fit <- glm(use ~ wind, family = binomial(), shuttle)
summary(fit)
# ans = -0.03181

# Q.2--- not answered
str(shuttle)
#[1] "stability" "error"     "sign"      "wind"      "magn"      "vis"      [7] "use" 
fit <- glm(use ~ wind + magn, family = binomial(), shuttle)
summary(fit)$coef

# Q.3--- not answered
fit <- glm(use ~ wind, family = binomial(), shuttle)
summary(fit)$coef
fit1 <- glm(use~ wind-1, family = binomial(), shuttle)
summary(fit1)$coef



# Q.4-- incorrect
fit <- glm(count ~ factor(spray)-1, family = poisson(), InsectSprays)
summary(fit)$coef
summary(fit)$coef[1]-summary(fit)$coef[2]
# ans = -0.05588046

# Q.5--- not answered


# Q.6--- not answered
x <- -5:5
y <- c(5.12, 3.93, 2.67, 1.87, 0.52, 0.08, 0.93, 2.05, 2.54, 3.87, 4.97)
plot(x,y)
fit <- lm(y~x)
summary(fit)$coef
abline(fit,col="red",lwd=3)


# library(rgl)
# z <- -4:4
# plot3d(x, y, z)
