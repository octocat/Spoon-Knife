library(UsingR)
# standard linear regression for price vs carat
fit <- lm(price ~ carat, data = diamond)
# intercept and slope
coef(fit)
## (Intercept)  carat
## -259.6259    3721.0249

# mean-centered regression
fit2 <- lm(price ~ I(carat - mean(carat)), data = diamond)
# intercept and slope
coef(fit2)
## (Intercept)  I(carat - mean(carat))
## 500.0833     3721.0249
# we expect 3721.02 (SIN) dollar increase in price for every carat increase
# in mass of diamond

# regression with more granular scale (1/10th carat)
fit3 <- lm(price ~ I(carat * 10), data = diamond)
# intercept and slope
coef(fit3)
## (Intercept) I(carat * 10)
## -259.6259    372.1025
# 372.1 (SIN) dollar increase in price for every 1/10 carat increase in 
# mass of diamond

# predictions for 3 values
newx <- c(0.16, 0.27, 0.34)
# manual calculations
coef(fit)[1] + coef(fit)[2] * newx
## [1] 335.7381 745.0508 1005.5225
# prediction using the predict function
predict(fit, newdata = data.frame(carat = newx))
## 1            2       3
## 335.7381 745.0508 1005.5225
# for 0.16, 0.27, and 0.34 carats, we predict the prices to be 
# 335.74, 745.05, 1005.52 (SIN) dollars


