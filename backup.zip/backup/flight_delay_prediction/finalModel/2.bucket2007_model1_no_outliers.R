# continue from 1.explore2007_model1_no_outliers.R
names(dataset_final2007)
# [1] "CST"                       "Year"                      "Month"                    
# [4] "DayofMonth"                "DayOfWeek"                 "Origin"                   
# [7] "Dest"                      "Mean.TemperatureF"         "MeanDew.PointF"           
# [10] "Mean.Sea.Level.PressureIn" "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"        
# [13] "Events"                    "WindDirDegrees"            "WeatherDelay"             
# [16] "WDelay" 

write.csv(x = dataset_final2007, file = "dataset_final2007.csv")


# bucketing variables randomly***
tempDatasetFinal2007 <- dataset_final2007

# finding ranges corresponding to 10 buckets
a <- quantile(tempDatasetFinal2007$Max.TemperatureF, probs = seq(0, 1, by = 0.05))
a
# 0%   5%  10%  15%  20%  25%  30%  35%  40%  45%  50%  55%  60%  65%  70% 
# 39   55   63   70   73   76   78   79   81   83   84   87   89   90   91 
# 75%  80%  85%  90%  95% 100% 
# 92   94   95   96   98  104 

summary(tempDatasetFinal2007$Max.TemperatureF)
i = 1
while (i < 21) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$Max.TemperatureF[tempDatasetFinal2007$Max.TemperatureF > lowRange & 
                                              tempDatasetFinal2007$Max.TemperatureF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Max.TemperatureF)
quantile(tempDatasetFinal2007$Max.TemperatureF, probs = seq(0, 1, by = 0.05))

a <- quantile(tempDatasetFinal2007$Min.DewpointF, probs = seq(0, 1, by = 0.05))
a
summary(tempDatasetFinal2007$Min.DewpointF)
i = 1
while (i < 21) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$Min.DewpointF[tempDatasetFinal2007$Min.DewpointF > lowRange & 
                                            tempDatasetFinal2007$Min.DewpointF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Min.DewpointF)
quantile(tempDatasetFinal2007$Min.DewpointF, probs = seq(0, 1, by = 0.05))

a <- quantile(tempDatasetFinal2007$Max.Gust.SpeedMPH, probs = seq(0, 1, by = 0.05), na.rm = TRUE)
a
summary(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
i = 1
while (i < 21) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange, na.rm = TRUE))
        tempDatasetFinal2007$Max.Gust.SpeedMPH[tempDatasetFinal2007$Max.Gust.SpeedMPH > lowRange & 
                                                           tempDatasetFinal2007$Max.Gust.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
quantile(tempDatasetFinal2007$Max.Gust.SpeedMPH, probs = seq(0, 1, by = 0.05))

a <- quantile(tempDatasetFinal2007$WindDirDegrees, probs = seq(0, 1, by = 0.05))
a
summary(tempDatasetFinal2007$WindDirDegrees)
i = 1
while (i < 21) {
        lowRange <- ceiling(a[i])
        upperRange <- ceiling(a[i+1])
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$WindDirDegrees[tempDatasetFinal2007$WindDirDegrees > lowRange & 
                                                           tempDatasetFinal2007$WindDirDegrees <= upperRange ] <- ceiling(medianRange)
        i = i + 1
}
summary(tempDatasetFinal2007$WindDirDegrees)
quantile(tempDatasetFinal2007$WindDirDegrees, probs = seq(0, 1, by = 0.05))

a <- quantile(tempDatasetFinal2007$Min.Sea.Level.PressureIn, probs = seq(0, 1, by = 0.05))
a
summary(tempDatasetFinal2007$Min.Sea.Level.PressureIn)
i = 1
while (i < 21) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- median(finalRange)
        tempDatasetFinal2007$Min.Sea.Level.PressureIn[tempDatasetFinal2007$Min.Sea.Level.PressureIn > lowRange & 
                                                    tempDatasetFinal2007$Min.Sea.Level.PressureIn <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Min.Sea.Level.PressureIn)
quantile(tempDatasetFinal2007$Min.Sea.Level.PressureIn, probs = seq(0, 1, by = 0.05))


write.csv(x = tempDatasetFinal2007, file = "Rebucket_No_Outliers.csv")
# bucketing done


