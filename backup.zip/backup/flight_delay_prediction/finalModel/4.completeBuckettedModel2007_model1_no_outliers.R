# continue from 2.bucket2007_Model1_no_outliers.R

# model
names(tempDatasetFinal2007)
# [1] "CST"                      "Year"                    
# [3] "Month"                    "DayofMonth"              
# [5] "DayOfWeek"                "Origin"                  
# [7] "Dest"                     "Max.TemperatureF"        
# [9] "Min.DewpointF"            "Min.Sea.Level.PressureIn"
# [11] "Max.Gust.SpeedMPH"        "WindDirDegrees"          
# [13] "WeatherDelay"             "WDelay"  

training <- tempDatasetFinal2007

write.csv(x = training, file = "VIFtrainingReFinal.csv")

# model building
mod <- glm(WDelay ~ ., family = binomial, data = training[, -c(1:7, 13)])

# model summary
summary(mod)

# continue from 3.explore2008_model1_no_outliers.R
names(dataset2008)
dataset2008 <- dataset2008[complete.cases(dataset2008), ]
dim(dataset2008)
testing <- dataset2008[, c(1:7, 9, 14, 20, 26, 29, 8, 30)]
names(testing)
write.csv(x = testing, file = "VIFtestingReFinal.csv")

# Predicting Test Score and Model Evaluation
# Prediction on test set
pred_prob <- predict(mod, newdata = testing, type = "response")
summary(pred_prob)
plot(pred_prob)


# model accuracy measures
library(ROCR)
pred <- prediction(pred_prob, testing$WDelay)

# creating ROC curve
roc <- performance (pred,"tpr","tnr")
plot(roc)

# create data frame of values
perf <- as.data.frame(cbind(roc@alpha.values[[1]], roc@x.values[[1]], roc@y.values[[1]]))
colnames(perf) <- c("Probability","TNR","TPR")

# removing infinity value from data frame
perf <- perf[-1,]

# reshape the data frame
library(reshape)
perf2<- melt(perf, measure.vars = c("TNR", "TPR"))

# plotting FPR, TPR on y axis and cut-off probability on x axis
library(ggplot2)
ggplot(perf2, aes(Probability, value, colour = variable)) +
        geom_line()+ theme_bw()
plot(perf2$Probability, perf2$value)
abline(h=0.625)

f2 <- approxfun(perf2$value, perf2$Probability)
v0 <- 0.625
f2(v0)
# 0.0316486


# model accuracy - Confusion Matrix
library(SDMTools)
confusion.matrix(testing$WDelay, pred_prob, threshold = 0.0316486)
# accuracy :- 60.51%

output <- cbind(testing[1:14])
output$WDelayYesOrNo[pred_prob <= 0.0316486] <- "No"
output$WDelayYesOrNo[pred_prob > 0.0316486] <- "Yes"
colnames(output)[15] <- "WDelayYesOrNo"
write.csv(output, "VIFRePredictionsBucketingNoOutliers.csv", row.names = T)

