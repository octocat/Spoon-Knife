# continue from 4.completeBuckettedModel2007_model1_no_outliers.R

# apply random forest
training$WDelay <- as.factor(training$WDelay)
library(randomForest)
fit <- randomForest(WDelay ~ ., data = training[, -c(1:7, 13)], ntree=10)
summary(fit)

#Predict Output 
predicted = predict(fit, testing)

# tabulate results
table(predicted, testing$WDelay)
# predicted     0       1
#       0       62142  6910
#       1       705     107
# > 62249/69864
# total accuracy = 0.8910025
# TPR = 62142/62142+705 = 0.9904848
# TNR = 107/6910+107 = 0.01524868

set.seed(5)
fit <- randomForest(WDelay ~ ., data = training[, -c(1:7, 13)], ntree=20)
summary(fit)

#Predict Output 
predicted = predict(fit, testing)

# tabulate results
table(predicted, testing$WDelay)
# predicted     0       1
#       0       62223  6619
#       1       624     398
# > 62621/69864
# total accuracy = 0.8963271
# TPR = 62223/(62223+624) = 0.9900711
# TNR = 398/6619+398 = 0.0567194