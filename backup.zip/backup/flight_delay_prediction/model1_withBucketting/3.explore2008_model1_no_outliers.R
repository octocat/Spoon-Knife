# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2008Copy <- read.csv(file = "D:\\flight_delay_prediction\\zip\\pending\\2008.csv")
flightData2008 <- flightData2008Copy
dim(flightData2008)
str(flightData2008)

# subsetting flight data for year 2007 for particular origin
subsetFlightData2008 <- subset(flightData2008, (Origin == "DFW"))

dim(subsetFlightData2008)
str(subsetFlightData2008)

# combining Year, Month and DayOfMonth columns of flightData78
subsetFlightData2008$CST <- with(subsetFlightData2008, 
                                 paste(Year, Month, DayofMonth, sep = "-"))
str(subsetFlightData2008$CST)

# changing datatype of CST of flightData2007
subsetFlightData2008$CST <- as.Date(as.character(subsetFlightData2008$CST, 
                                                 format = "%Y/%m/%d"))
str(subsetFlightData2008$CST)

# sorting data datewise
subsetFlightData2008 <- subsetFlightData2008[order(as.Date(
        subsetFlightData2008$CST, 
        format = "%Y/%m/%d")), ]
head(subsetFlightData2008$CST)


# Weather features:
# reading weather data for year 2007
weatherData2008 <- read.csv(file = "D:\\flight_delay_prediction\\zip\\pending\\DFW_2008.csv")
dim(weatherData2008)
str(weatherData2008)

# changing datatype of CST of weatherData2007
weatherData2008$CST <- trimws(weatherData2008$CST)
weatherData2008$CST <- as.Date(as.character(weatherData2008$CST, 
                                            format = "%Y/%m/%d"))
# complete weatherData2007

# merging flightData78 and weatherData78 by column CST
FlightWeatherData2008 <- merge(x = subsetFlightData2008, 
                               y = weatherData2008, by = "CST")
dim(FlightWeatherData2008)
str(FlightWeatherData2008)
# complete FlightWeatherData2008
# write.csv(x = FlightWeatherData2008, file = "FlightWeatherData2008.csv")



# columns not included in flightWeatherData2007 as these columns are 
# irrelevant
names(FlightWeatherData2008)
col <- c(11, 12, 23, 24, 26, 28:30)
FlightWeatherDf <- FlightWeatherData2008[, -col]
names(FlightWeatherDf)

# creating new variable WDelay as binary(it is dependent variable)
FlightWeatherDf$WDelay[FlightWeatherDf$WeatherDelay == 0] <- 0
FlightWeatherDf$WDelay[FlightWeatherDf$WeatherDelay > 0] <- 1

# irrelevant columns
col1 <- c(6:15, 18:21)

dataset2008 <- FlightWeatherDf[, -col1]
names(dataset2008)

colnames(dataset2008)[apply(is.na(dataset2008), 2, any)]

dataset2008 <- dataset2008[complete.cases(dataset2008), ]
dim(dataset2008)
summary(dataset2008)
# checking outliers
a <- boxplot(dataset2008$Mean.TemperatureF)
a$stats
# no outliers in Mean.TemperatureF

a <- boxplot(dataset2008$MeanDew.PointF)
a$stats
# no outliers in MeanDew.PointF

a <- boxplot(dataset2008$Mean.Sea.Level.PressureIn)
a$stats
# 29.54 - 30.37

a <- boxplot(dataset2008$Max.Wind.SpeedMPH)
a$stats
# 9 - 47

a <- boxplot(dataset2008$Max.Gust.SpeedMPH)
a$stats
# 10 - 54

a <- boxplot(dataset2008$WindDirDegrees)
a$stats
# no outliers in WindDirDegrees

dataset2008 <- subset(dataset2008, (Mean.Sea.Level.PressureIn >= 29.54 & 
                                    Mean.Sea.Level.PressureIn <= 30.37))

dataset2008 <- subset(dataset2008, (Max.Wind.SpeedMPH >= 9 & 
                                    Max.Wind.SpeedMPH <= 47))

dataset2008 <- subset(dataset2008, (Max.Gust.SpeedMPH >= 10 & 
                                    Max.Gust.SpeedMPH <= 54))
summary(dataset2008)

