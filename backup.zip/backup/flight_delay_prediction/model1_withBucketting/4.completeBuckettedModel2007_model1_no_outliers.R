# continue from 2.bucket2007_Model1_no_outliers.R
# removing NAs
newDataset <- tempDatasetFinal2007[complete.cases(tempDatasetFinal2007),]

# model
names(newDataset)
# [1] "CST"                       "Year"                     
# [3] "Month"                     "DayofMonth"               
# [5] "DayOfWeek"                 "Origin"                   
# [7] "Dest"                      "Mean.TemperatureF"        
# [9] "MeanDew.PointF"            "Mean.Sea.Level.PressureIn"
# [11] "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"        
# [13] "Events"                    "WindDirDegrees"           
# [15] "WeatherDelay"              "WDelay" 
training <- newDataset
# training <- newDataset[, -c(1:7, 15)]
# names(training)
write.csv(x = newDataset, file = "training1.csv")

# model building
mod <- glm(WDelay ~ ., family = binomial, data = training[, -c(1:7, 15)])

# model summary
summary(mod)

# continue from 3.explore2008_model1_no_outliers.R
tempDataset <- subset(dataset2008, Events != "Fog-Rain-Snow-Thunderstorm")

# removing NA's from 2008data
tempDataset <- tempDataset[complete.cases(tempDataset),]
names(tempDataset)
testing <- tempDataset[, c(1:7, 10, 13, 19, 24, 26, 29, 30, 8, 31)]
write.csv(x = testing, file = "testing1.csv")

# Predicting Test Score and Model Evaluation
# Prediction on test set
pred_prob <- predict(mod, newdata = testing, type = "response")
summary(pred_prob)
plot(pred_prob)


# model accuracy measures
library(ROCR)
pred <- prediction(pred_prob, testing$WDelay)

# creating ROC curve
roc <- performance (pred,"tpr","tnr")
plot(roc)

# create data frame of values
perf <- as.data.frame(cbind(roc@alpha.values[[1]], roc@x.values[[1]], roc@y.values[[1]]))
colnames(perf) <- c("Probability","TNR","TPR")

# removing infinity value from data frame
perf <- perf[-1,]

# reshape the data frame
library(reshape)
perf2<- melt(perf, measure.vars = c("TNR", "TPR"))

# plotting FPR, TPR on y axis and cut-off probability on x axis
library(ggplot2)
ggplot(perf2, aes(Probability, value, colour = variable)) +
        geom_line()+ theme_bw()
plot(perf2$Probability, perf2$value)
abline(h=0.75)

f2 <- approxfun(perf2$value, perf2$Probability)
v0 <- 0.75
f2(v0)
# 0.02096755


# model accuracy - Confusion Matrix
library(SDMTools)
confusion.matrix(testing$WDelay, pred_prob, threshold = 0.02096755)
# accuracy :- 75.19%

output <- cbind(testing[, c(1:7, 10, 13, 19, 24, 26, 29, 30, 8, 31)])
output$WDelayYesOrNo[pred_prob <= 0.02096755] <- "No"
output$WDelayYesOrNo[pred_prob > 0.02096755] <- "Yes"
colnames(output)[17] <- "WDelayYesOrNo"
write.csv(output, "model1_withBucketting/PredictionsBucketingNoOutliers.csv", row.names = T)

