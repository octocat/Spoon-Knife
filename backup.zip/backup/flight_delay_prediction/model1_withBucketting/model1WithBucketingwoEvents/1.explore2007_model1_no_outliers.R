# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "D:\\flight_delay_prediction\\zip\\pending\\2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)
str(flightData2007)

# subsetting flight data for year 2007 for particular origin
subsetFlightData2007 <- subset(flightData2007, (Origin == "DFW"))
                                       
dim(subsetFlightData2007)
str(subsetFlightData2007)

# combining Year, Month and DayOfMonth columns of flightData78
subsetFlightData2007$CST <- with(subsetFlightData2007, 
                                paste(Year, Month, DayofMonth, sep = "-"))
str(subsetFlightData2007$CST)

# changing datatype of CST of flightData2007
subsetFlightData2007$CST <- as.Date(as.character(subsetFlightData2007$CST, 
                                                format = "%Y/%m/%d"))
str(subsetFlightData2007$CST)

# sorting data datewise
subsetFlightData2007 <- subsetFlightData2007[order(as.Date(
        subsetFlightData2007$CST, 
        format = "%Y/%m/%d")), ]
head(subsetFlightData2007$CST)


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "D:\\flight_delay_prediction\\zip\\pending\\DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, 
                                            format = "%Y/%m/%d"))
weatherData2007 <- weatherData2007[complete.cases(weatherData2007), ]
# complete weatherData2007

# merging flightData78 and weatherData78 by column CST
FlightWeatherData2007 <- merge(x = subsetFlightData2007, 
                               y = weatherData2007, by = "CST")
dim(FlightWeatherData2007)
str(FlightWeatherData2007)
# complete delayedFlightWeatherData2007
# write.csv(x = FlightWeatherData2007, file = "FlightWeatherData2007.csv")



# columns not included in flightWeatherData2007 as these columns are 
# irrelevant
names(FlightWeatherData2007)
col <- c(11, 12, 23, 24, 26, 28:30)
FlightWeatherDf <- FlightWeatherData2007[, -col]
names(FlightWeatherDf)

# creating new variable WDelay as binary(it is dependent variable)
FlightWeatherDf$WDelay[FlightWeatherDf$WeatherDelay == 0] <- 0
FlightWeatherDf$WDelay[FlightWeatherDf$WeatherDelay > 0] <- 1

# irrelevant columns
col1 <- c(6:15, 18:21)

dataset2007 <- FlightWeatherDf[, -col1]
names(dataset2007)

# # write.csv(x = dataset, file = "dataset2007.csv")
# # variable selection
# # install.packages("devtools") 
 library(devtools) 
# # install_github("tomasgreif/woe") 
 library(woe)
# # calculation of information value 
 row.names(dataset2007) <- 1:nrow(dataset2007) 
 IV <- iv.mult(dataset2007[, -c(1:8)], y="WDelay", TRUE)
 IV
 iv.plot.summary(IV)
 
# # selecting variables with 0.1<IV<0.5
 var <- IV[which(IV$InformationValue > 0.1),]
 var1 <- var[which(var$InformationValue < 0.5),]
 
 final_var <- var1$Variable
 final_var
# # [1] "Min.DewpointF"             "Max.Dew.PointF"           
# # [3] "Max.Wind.SpeedMPH"         "MeanDew.PointF"           
# # [5] "WindDirDegrees"            "Mean.TemperatureF"        
# # [7] "Min.TemperatureF"          "Max.TemperatureF"         
# # [9] "Max.Gust.SpeedMPH"         "Mean.Sea.Level.PressureIn"
# # [11] "Min.Sea.Level.PressureIn" 

 
 
 
# here we choose mean variables
names(dataset2007)
col <- c(1:7, 10, 13, 19, 24, 26, 30, 8, 31)
dataset_final2007<-cbind(dataset2007[, col])
names(dataset_final2007) # final variables
# [1] "CST"                       "Year"                     
# [3] "Month"                     "DayofMonth"               
# [5] "DayOfWeek"                 "Origin"                   
# [7] "Dest"                      "Mean.TemperatureF"        
# [9] "MeanDew.PointF"            "Mean.Sea.Level.PressureIn"
# [11] "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"        
# [13] "WindDirDegrees"            "WeatherDelay"             
# [15] "WDelay"    

str(dataset_final2007)

# checking outliers
a <- boxplot(dataset_final2007$Mean.TemperatureF)
a$stats
# no outliers in Mean.TemperatureF

a <- boxplot(dataset_final2007$MeanDew.PointF)
a$stats
# no outliers in MeanDew.PointF

a <- boxplot(dataset_final2007$Mean.Sea.Level.PressureIn)
a$stats
# 29.66 - 30.37

a <- boxplot(dataset_final2007$Max.Wind.SpeedMPH)
a$stats
# 7 - 39

a <- boxplot(dataset_final2007$Max.Gust.SpeedMPH)
a$stats
# 10 - 47

a <- boxplot(dataset_final2007$WindDirDegrees)
a$stats
# 43 - 274
 
dataset_final2007 <- subset(dataset_final2007, (Mean.Sea.Level.PressureIn >= 29.66 & 
                                                Mean.Sea.Level.PressureIn <= 30.37))

dataset_final2007 <- subset(dataset_final2007, (Max.Wind.SpeedMPH >= 7 & 
                                                Max.Wind.SpeedMPH <= 39))

dataset_final2007 <- subset(dataset_final2007, (Max.Gust.SpeedMPH >= 10 & 
                                                Max.Gust.SpeedMPH <= 47))

dataset_final2007 <- subset(dataset_final2007, (WindDirDegrees >= 43 & 
                                                WindDirDegrees <= 274))
dim(dataset_final2007)
dataset_final2007NoBucket <- dataset_final2007
# create training and test data
library(caret)
inTrain <- createDataPartition(y = dataset_final2007NoBucket$WDelay, p=0.7, 
                               list = FALSE)
training <- dataset_final2007NoBucket[inTrain, ]
dim(training)
write.csv(x = testing, file = "trainingNoBucket.csv")
testing <- dataset_final2007NoBucket[-inTrain, ]
dim(testing)
write.csv(x = testing, file = "testingNoBucket.csv")

# model
names(training)
trainingFinal <- training[, -c(1:7, 14)]
names(trainingFinal)
# [1] "Mean.TemperatureF"         "MeanDew.PointF"            "Mean.Sea.Level.PressureIn"
# [4] "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"         "WindDirDegrees"           
# [7] "WDelay"  

# model building w/o bucketting
mod <- glm(WDelay ~ ., family = binomial, data = training[, -c(1:7, 14)])

# model summary
summary(mod)

model <- glm(WDelay ~ ., family = binomial, data = training[, -c(1:7, 10, 14)])
# 
# # model summary
 summary(model)
# save(mod, file = "D:/flight_delay_prediction/zip/pending/model1_withBucketting/model1WithBucketingwoEvents/mymodelNoBucket.rda")
# Predicting Test Score and Model Evaluation
# Prediction on test set
pred_prob <- predict(model, newdata = testing, type = "response")
summary(pred_prob)
plot(pred_prob)

# model accuracy measures
library(ROCR)
pred <- prediction(pred_prob, testing$WDelay)

# creating ROC curve
roc <- performance (pred,"tpr","tnr")
plot(roc)

# create data frame of values
perf <- as.data.frame(cbind(roc@alpha.values[[1]], roc@x.values[[1]], roc@y.values[[1]]))
colnames(perf) <-c("Probability","TNR","TPR")

# removing infinity value from data frame
perf <-perf[-1,]

# reshape the data frame
library(reshape)
perf2<- melt(perf, measure.vars = c("TNR", "TPR"))

# plotting FPR, TPR on y axis and cut-off probability on x axis
library(ggplot2)
ggplot(perf2, aes(Probability, value, colour = variable)) +
        geom_line()+ theme_bw()
plot(perf2$Probability, perf2$value)
abline(h=0.75)

f2 <- approxfun(perf2$value, perf2$Probability)
v0 <- 0.75
f2(v0)
# 0.07244281


# model accuracy - Confusion Matrix
library(SDMTools)
confusion.matrix(testing$WDelay, pred_prob, threshold = 0.07244281)
# accuracy :- 76.34%

output <- cbind(testing[, c(1:9, 11:15)])
output$PredProb <- pred_prob
colnames(output)[15] <- "PredProb"
output$WDelayYesOrNo[pred_prob <= 0.07244281] <- "No"
output$WDelayYesOrNo[pred_prob > 0.07244281] <- "Yes"
colnames(output)[16] <- "WDelayYesOrNo"


write.csv(output, "D:/flight_delay_prediction/zip/pending/model1_withBucketting/model1WithBucketingwoEvents/PredictionsWoBucketingNoEventNoOutliers.csv", row.names = T)
