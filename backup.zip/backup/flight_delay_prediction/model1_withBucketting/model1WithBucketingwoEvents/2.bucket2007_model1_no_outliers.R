# continue from 1.explore2007_model1_no_outliers.R
names(dataset_final2007)
# [1] "CST"                       "Year"                      "Month"                    
# [4] "DayofMonth"                "DayOfWeek"                 "Origin"                   
# [7] "Dest"                      "Mean.TemperatureF"         "MeanDew.PointF"           
# [10] "Mean.Sea.Level.PressureIn" "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"        
# [13] "Events"                    "WindDirDegrees"            "WeatherDelay"             
# [16] "WDelay" 

write.csv(x = dataset_final2007, file = "D:/flight_delay_prediction/zip/pending/model1_withBucketting/model1WithBucketingwoEvents/dataset_final2007.csv")


# bucketing variables randomly***
tempDatasetFinal2007 <- dataset_final2007

# finding ranges corresponding to 10 buckets
a <- quantile(tempDatasetFinal2007$Mean.TemperatureF, probs = seq(0, 1, by = 0.1))
a
# 0%  10%  20%  30%  40%  50%  60%  70%  80%  90% 100% 
# 33   52   61   68   72   76   80   82   85   87   92 

summary(tempDatasetFinal2007$Mean.TemperatureF)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$Mean.TemperatureF[tempDatasetFinal2007$Mean.TemperatureF > lowRange & 
                                                           tempDatasetFinal2007$Mean.TemperatureF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Mean.TemperatureF)
quantile(tempDatasetFinal2007$Mean.TemperatureF, probs = seq(0, 1, by = 0.1))

a <- quantile(tempDatasetFinal2007$MeanDew.PointF, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$MeanDew.PointF)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$MeanDew.PointF[tempDatasetFinal2007$MeanDew.PointF > lowRange & 
                                                           tempDatasetFinal2007$MeanDew.PointF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$MeanDew.PointF)
quantile(tempDatasetFinal2007$MeanDew.PointF, probs = seq(0, 1, by = 0.1))

a <- quantile(tempDatasetFinal2007$Max.Wind.SpeedMPH, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$Max.Wind.SpeedMPH)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$Max.Wind.SpeedMPH[tempDatasetFinal2007$Max.Wind.SpeedMPH > lowRange & 
                                                        tempDatasetFinal2007$Max.Wind.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Max.Wind.SpeedMPH)
quantile(tempDatasetFinal2007$Max.Wind.SpeedMPH, probs = seq(0, 1, by = 0.1))

a <- quantile(tempDatasetFinal2007$Max.Gust.SpeedMPH, probs = seq(0, 1, by = 0.1), na.rm = TRUE)
a
summary(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange, na.rm = TRUE))
        tempDatasetFinal2007$Max.Gust.SpeedMPH[tempDatasetFinal2007$Max.Gust.SpeedMPH > lowRange & 
                                                           tempDatasetFinal2007$Max.Gust.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
quantile(tempDatasetFinal2007$Max.Gust.SpeedMPH, probs = seq(0, 1, by = 0.1), na.rm = TRUE)

a <- quantile(tempDatasetFinal2007$WindDirDegrees, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$WindDirDegrees)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$WindDirDegrees[tempDatasetFinal2007$WindDirDegrees > lowRange & 
                                                           tempDatasetFinal2007$WindDirDegrees <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$WindDirDegrees)
quantile(tempDatasetFinal2007$WindDirDegrees, probs = seq(0, 1, by = 0.1))

a <- quantile(tempDatasetFinal2007$Mean.Sea.Level.PressureIn, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$Mean.Sea.Level.PressureIn)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- median(finalRange)
        tempDatasetFinal2007$Mean.Sea.Level.PressureIn[tempDatasetFinal2007$Mean.Sea.Level.PressureIn > lowRange & 
                                                    tempDatasetFinal2007$Mean.Sea.Level.PressureIn <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Mean.Sea.Level.PressureIn)
quantile(tempDatasetFinal2007$Mean.Sea.Level.PressureIn, probs = seq(0, 1, by = 0.1))


write.csv(x = tempDatasetFinal2007, file = "D:/flight_delay_prediction/zip/pending/model1_withBucketting/model1WithBucketingwoEvents/bucket_No_Outliers_No_Event.csv")
# bucketing done


