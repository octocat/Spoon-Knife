# continue from 2.bucket2007_Model1_no_outliers.R
# removing NAs
newDataset <- tempDatasetFinal2007[complete.cases(tempDatasetFinal2007),]

# model
names(newDataset)
# [1] "CST"                       "Year"                      "Month"                    
# [4] "DayofMonth"                "DayOfWeek"                 "Origin"                   
# [7] "Dest"                      "Mean.TemperatureF"         "MeanDew.PointF"           
# [10] "Mean.Sea.Level.PressureIn" "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"        
# [13] "WindDirDegrees"            "WeatherDelay"              "WDelay"      
training <- newDataset

write.csv(x = newDataset, file = "trainingBucketting.csv")

# model building
mod <- glm(WDelay ~ ., family = binomial, data = training[, -c(1:7, 14)])

# model summary
summary(mod)

# continue from 3.explore2008_model1_no_outliers.R
tempDataset <- subset(dataset2008, Events != "Fog-Rain-Snow-Thunderstorm")

# removing NA's from 2008data
tempDataset <- tempDataset[complete.cases(tempDataset),]
names(tempDataset)
testing <- tempDataset[, c(1:7, 10, 13, 19, 24, 26, 30, 8, 31)]
write.csv(x = testing, file = "testingBucketting.csv")

# Predicting Test Score and Model Evaluation
# Prediction on test set
pred_prob <- predict(mod, newdata = testing, type = "response")
summary(pred_prob)
plot(pred_prob)


# model accuracy measures
library(ROCR)
pred <- prediction(pred_prob, testing$WDelay)

# creating ROC curve
roc <- performance (pred,"tpr","tnr")
plot(roc)

# create data frame of values
perf <- as.data.frame(cbind(roc@alpha.values[[1]], roc@x.values[[1]], roc@y.values[[1]]))
colnames(perf) <- c("Probability","TNR","TPR")

# removing infinity value from data frame
perf <- perf[-1,]

# reshape the data frame
library(reshape)
perf2<- melt(perf, measure.vars = c("TNR", "TPR"))

# plotting FPR, TPR on y axis and cut-off probability on x axis
library(ggplot2)
ggplot(perf2, aes(Probability, value, colour = variable)) +
        geom_line()+ theme_bw()
plot(perf2$Probability, perf2$value)
abline(h=0.65)

f2 <- approxfun(perf2$value, perf2$Probability)
v0 <- 0.65
f2(v0)
# 0.04631187


# model accuracy - Confusion Matrix
library(SDMTools)
confusion.matrix(testing$WDelay, pred_prob, threshold = 0.04631187)
# accuracy :- 65.06%

output <- cbind(testing[1:15])
output$WDelayYesOrNo[pred_prob <= 0.04631187] <- "No"
output$WDelayYesOrNo[pred_prob > 0.04631187] <- "Yes"
colnames(output)[16] <- "WDelayYesOrNo"
write.csv(output, "D:/flight_delay_prediction/zip/pending/model1_withBucketting/model1WithBucketingwoEvents/PredictionsBucketingNoOutliersNoEvents.csv", row.names = T)

