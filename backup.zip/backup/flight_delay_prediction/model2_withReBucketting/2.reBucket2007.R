
# here we choose mean variables
names(dataset_final2007)

# bucketing variables randomly***
tempDatasetFinal1 <- dataset_final2007

# finding minimum and maximum
minMeanTemp <- min(tempDatasetFinal1$Mean.TemperatureF)
minMeanTemp
maxMeanTemp <- max(tempDatasetFinal1$Mean.TemperatureF)
maxMeanTemp
Range <- maxMeanTemp - minMeanTemp
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Mean.TemperatureF)
i = 1
while (i < 11) {
        lowRange <- minMeanTemp + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxMeanTemp){
                upperRange <- maxMeanTemp
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$Mean.TemperatureF[tempDatasetFinal1$Mean.TemperatureF > lowRange & 
                                                   tempDatasetFinal1$Mean.TemperatureF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Mean.TemperatureF)


# finding minimum and maximum
minMeanDew <- min(tempDatasetFinal1$MeanDew.PointF)
minMeanDew
maxMeanDew <- max(tempDatasetFinal1$MeanDew.PointF)
maxMeanDew
Range <- maxMeanDew - minMeanDew
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$MeanDew.PointF)
i = 1
while (i < 11) {
        lowRange <- minMeanDew + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxMeanDew){
                upperRange <- maxMeanDew
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$MeanDew.PointF[tempDatasetFinal1$MeanDew.PointF > lowRange & 
                                                    tempDatasetFinal1$MeanDew.PointF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$MeanDew.PointF)


# finding minimum and maximum
minWind <- min(tempDatasetFinal1$Max.Wind.SpeedMPH)
minWind
maxWind <- max(tempDatasetFinal1$Max.Wind.SpeedMPH)
maxWind
Range <- maxWind - minWind
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Max.Wind.SpeedMPH)
i = 1
while (i < 11) {
        lowRange <- minWind + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxWind){
                upperRange <- maxWind
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$Max.Wind.SpeedMPH[tempDatasetFinal1$Max.Wind.SpeedMPH > lowRange & 
                                                 tempDatasetFinal1$Max.Wind.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Max.Wind.SpeedMPH)


# finding minimum and maximum
minGust <- min(tempDatasetFinal1$Max.Gust.SpeedMPH)
minGust
maxGust <- max(tempDatasetFinal1$Max.Gust.SpeedMPH)
maxGust
Range <- maxGust - minGust
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Max.Gust.SpeedMPH)
i = 1
while (i < 11) {
        lowRange <- minGust + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxGust){
                upperRange <- maxGust
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$Max.Gust.SpeedMPH[tempDatasetFinal1$Max.Gust.SpeedMPH > lowRange & 
                                                    tempDatasetFinal1$Max.Gust.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Max.Gust.SpeedMPH)


# finding minimum and maximum
minWindDir <- min(tempDatasetFinal1$WindDirDegrees)
minWindDir
maxWindDir <- max(tempDatasetFinal1$WindDirDegrees)
maxWindDir
Range <- maxWindDir - minWindDir
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$WindDirDegrees)
i = 1
while (i < 11) {
        lowRange <- minWindDir + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxWindDir){
                upperRange <- maxWindDir
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$WindDirDegrees[tempDatasetFinal1$WindDirDegrees > lowRange & 
                                                    tempDatasetFinal1$WindDirDegrees <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$WindDirDegrees)

# finding minimum and maximum
minSeaLevel <- min(tempDatasetFinal1$Mean.Sea.Level.PressureIn)
minSeaLevel
maxSeaLevel <- max(tempDatasetFinal1$Mean.Sea.Level.PressureIn)
maxSeaLevel
Range <- maxSeaLevel - minSeaLevel
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Mean.Sea.Level.PressureIn)
i = 1
while (i < 11) {
        lowRange <- minSeaLevel + (i-1)*(Range/10)
        upperRange <- (Range/10) + lowRange
        if(upperRange > maxSeaLevel){
                upperRange <- maxSeaLevel
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- median(finalRange)
        tempDatasetFinal1$Mean.Sea.Level.PressureIn[tempDatasetFinal1$Mean.Sea.Level.PressureIn > lowRange & 
                                                 tempDatasetFinal1$Mean.Sea.Level.PressureIn <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Mean.Sea.Level.PressureIn)

write.csv(x = tempDatasetFinal1, file = "model2_withReBucketting/reBucket_no_Outliers.csv")
# bucketing done
