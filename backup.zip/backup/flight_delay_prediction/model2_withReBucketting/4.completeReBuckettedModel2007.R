# continue from reBucket2007.R
# removing NAs
newDataset1 <- tempDatasetFinal1[complete.cases(tempDatasetFinal1),]
names(newDataset1)

# model
training1 <- newDataset1[, -c(1:7, 15)]
names(training1)
# [1] "Mean.TemperatureF"         "MeanDew.PointF"           
# [3] "Mean.Sea.Level.PressureIn" "Max.Wind.SpeedMPH"        
# [5] "Max.Gust.SpeedMPH"         "Events"                   
# [7] "WindDirDegrees"            "WDelay"     

# model building
mod1 <- glm(WDelay ~ ., family = binomial, data = training1)

# model summary
summary(mod1)

training1 <- training1[, c(2, 3, 6, 7, 8)]
# model building
model1 <- glm(WDelay ~ ., family = binomial, data = training1)

# model summary
summary(model1)

# continue from explore2008.R
tempDataset1 <- subset(dataset2008, Events != "Fog-Rain-Snow-Thunderstorm")

# removing NA's from 2008data
tempDataset1 <- tempDataset1[complete.cases(tempDataset1),]

testing1 <- tempDataset1
names(testing1)
# Predicting Test Score and Model Evaluation
# Prediction on test set
pred_prob1 <- predict(model1, newdata = testing1, type = "response")
summary(pred_prob1)
plot(pred_prob1)


# model accuracy measures
library(ROCR)
pred1 <- prediction(pred_prob1, testing1$WDelay)

# creating ROC curve
roc1 <- performance (pred1,"tpr","tnr")
plot(roc1)

# create data frame of values
perf1 <- as.data.frame(cbind(roc1@alpha.values[[1]], roc1@x.values[[1]], roc1@y.values[[1]]))
colnames(perf1) <-c("Probability","TNR","TPR")

# removing infinity value from data frame
perf1 <-perf1[-1,]

# reshape the data frame
library(reshape)
perf21<- melt(perf1, measure.vars = c("TNR", "TPR"))

# plotting FPR, TPR on y axis and cut-off probability on x axis
library(ggplot2)
ggplot(perf21, aes(Probability, value, colour = variable)) +
        geom_line()+ theme_bw()
plot(perf21$Probability, perf21$value)
abline(h=0.77)

f21 <- approxfun(perf21$value, perf21$Probability)
v01 <- 0.77
f21(v01)
# 0.0275633


# model accuracy - Confusion Matrix
library(SDMTools)
confusion.matrix(testing1$WDelay, pred_prob1, threshold = 0.0275633)
# accuracy :- 77.83%


output1 <- cbind(testing1[, c(1:7, 13, 19, 29, 30, 8, 31)])
output1$WDelayYesOrNo[pred_prob1 <= 0.0275633] <- "No"
output1$WDelayYesOrNo[pred_prob1 > 0.0275633] <- "Yes"
colnames(output1)[14] <- "WDelayYesOrNo"
write.csv(output1, "model2_withReBucketting/PredictionsReBucketingNoOutliers.csv", row.names = T)
