data7 <- read.csv(file = "2007.csv")
data71 <- data7
str(data71)
mydata7 <- subset(data71, (UniqueCarrier == "AA") & (Origin == "ORD"))
nrow(mydata7)

data8 <- read.csv(file = "2008.csv")
data81 <- data8
str(data81)
mydata8 <- subset(data81, (UniqueCarrier == "AA") & (Origin == "ORD"))
nrow(mydata8)

completedata <- rbind(mydata7, mydata8)
dim(completedata)
str(completedata)
# All flight columns are taken as it is.

# Airplane features:
planedataAll <- read.csv(file = "plane-data.csv")
dim(planedataAll)
str(planedataAll)


mis_valPlane<-sapply(planedataAll, function(x) (sum(is.na(x))/nrow(df)*100))
perMisPlane <- round(mis_valPlane, 1)
perMisPlane


planedataAll[planedataAll == ""] <- NA

planedata <- na.omit(planedataAll)
dim(planedata)
# All plane columns are taken as it is after eleminating empty rows..

# Merging plane-data to completedata by tailnum
m <- merge(x = completedata, y = planedata, by.x = "TailNum", by.y = "tailnum")
dim(m)
str(m)


# Weather features:
weatherdata7 <- read.csv(file = "DFW_2007.csv")
dim(weatherdata7)
str(weatherdata7)

weatherdata8 <- read.csv(file = "DFW_2008.csv")
dim(weatherdata8)
str(weatherdata8)

weatherdata78 <- rbind(weatherdata7, weatherdata8)
dim(weatherdata78)
str(weatherdata78)
# All weather columns are taken as it is.

# combining Year, Month and DayOfMonth columns of completedata
m$CST <- paste(m$Year, m$Month, m$DayofMonth, sep = "-")
str(m$CST)

# merging completedata and weatherdata78 by column CST
weatherdata78$CST <- trimws(weatherdata78$CST)
m1 <- merge(x = m, y = weatherdata78, by = "CST")
str(m1)
dim(m1)

# Now we replace blanks with NA
# These columns have NA's, so no need to replace NA
# DepTime, ArrTime, ActualElapsedTime, AirTime, ArrDelay, DepDelay, TaxiIn, 
# TaxiOut, CarrierDelay, WeatherDelay, NASDelay, SecurityDelay, 
# LateAircraftDelay, Max.Gust.SpeedMPH

# These columns have blanks, so replacing with NA's
# CancellationCode, type, manufacturer, issue_date, model, status, 
# aircraft_type, engine_type, year, Events

# m2 <- m1
# m1 <- m2
# str(m2)
# write.csv(x = m2, file = "a.csv")
# m1[m1 == ""] <- -1
m1[is.na(m1)] <- -1

# convert to date data-type
m1$CST <- as.Date(as.character(m1$CST, format = "%m/%d/%y"))

# sorting data datewise
completeData78 <- m1[order(as.Date(m1$CST, format = "%m/%d/%y")), ]
dim(completeData78)
str(completeData78)
# write.csv(x = completeData78, file = "a.csv")


df <- completeData78
# Percent missing value for each variable
mis_val<-sapply(df, function(x) (sum(is.na(x))/nrow(df)*100))
perMis <- round(mis_val, 1)
perMis



# Exploring individual variables
# use summary and quantile for continuous variables; 
# use table for categorical variables.

# continuous variable :- ActualElapsedTime
summary(df$ActualElapsedTime)
quantile(df$ActualElapsedTime, probs = seq(0, 1, by= 0.05), na.rm=TRUE)
quantile(df$ActualElapsedTime, probs = seq(0.95, 1, by= 0.01), na.rm=TRUE)
# So the values above 306 can be capped at 306
# capping values 
# df$ActualElapsedTime[df$ActualElapsedTime > 306] <- 306

# DepTime
summary(df$DepTime)
quantile(df$DepTime, probs = seq(0, 1, by = 0.05), na.rm = TRUE)
quantile(df$DepTime, probs = seq(0, 0.05, by = 0.01), na.rm = TRUE)
quantile(df$DepTime, probs = seq(0, 0.01, by = 0.005), na.rm = TRUE)

# categorical variable :- Events
table(df$Events, useNA = "always")



# Now we select only those features that have impact on LateAircraftDelay





