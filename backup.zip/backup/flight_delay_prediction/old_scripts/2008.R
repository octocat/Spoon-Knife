rm(list=ls())
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)

subsetFlightData2007 <- subset(flightData2007, (Origin == "DFW"))
dim(subsetFlightData2007)
str(subsetFlightData2007)

# finding columns having NA's from subsetflightData2007
colnames(subsetFlightData2007)[apply(is.na(subsetFlightData2007), 2, any)]
