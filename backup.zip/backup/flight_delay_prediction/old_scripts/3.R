# flight features:
rm(list=ls())
col <- c(1, 2, 3, 4, 9, 16, 17, 18, 26)
# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy[, col]
str(flightData2007)

# subsetting flight data for year 2007 for particular carrier and origin
subsetflightData2007 <- subset(flightData2007, (UniqueCarrier == "AA") & (Origin == "DFW"))
nrow(subsetflightData2007)


# reading flight data for year 2008
flightData2008Copy <- read.csv(file = "2008.csv")
flightData2008 <- flightData2008Copy[, col]
str(flightData2008)

# subsetting flight data for year 2008 for particular carrier and origin
subsetflightData2008 <- subset(flightData2008, (UniqueCarrier == "AA") & (Origin == "DFW"))
nrow(subsetflightData2008)

# Combining flight data for 2007 & 2008
flightData78 <- rbind(subsetflightData2007, subsetflightData2008)
dim(flightData78)
str(flightData78)
# All flight columns are taken as it is.



# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# reading weather data for year 2008
weatherData2008 <- read.csv(file = "DFW_2008.csv")
dim(weatherData2008)
str(weatherData2008)

# Combining flight data for 2007 & 2008
weatherData78 <- rbind(weatherData2007, weatherData2008)
dim(weatherData78)
str(weatherData78)
# All weather columns are taken as it is.


# combining Year, Month and DayOfMonth columns of flightData78
flightData78$CST <- paste(flightData78$Year, flightData78$Month, flightData78$DayofMonth, sep = "-")
str(flightData78$CST)

# Variables: Year, Month, DayofMonth, DayOfWeek, DepTime, ArrTime,UniqueCarrier, ArrDelay, 
# DepDelay, Origin, Dest, Distance,TaxiIn, TaxiOut, CarrierDelay, WeatherDelay, NASDelay, 
# SecurityDelay,LateAircraftDelay


# merging flightData78 and weatherData78 by column CST
weatherData78$CST <- trimws(weatherData78$CST)
flightWeatherData78 <- merge(x = flightData78, y = weatherData78, by = "CST")
str(flightWeatherData78)
dim(flightWeatherData78)

# These columns have NA's
# DepTime, ArrTime, ActualElapsedTime, AirTime, ArrDelay, DepDelay, TaxiIn, 
# TaxiOut, CarrierDelay, WeatherDelay, NASDelay, SecurityDelay, 
# LateAircraftDelay, Max.Gust.SpeedMPH

# These columns have blanks
# CancellationCode, Events

# m1[m1 == ""] <- -1
# m1[is.na(m1)] <- -1

# convert to date data-type
flightWeatherData78$CST <- as.Date(as.character(flightWeatherData78$CST, format = "%m/%d/%y"))

# sorting data datewise
flightWeatherData78 <- flightWeatherData78[order(as.Date(flightWeatherData78$CST, format = "%m/%d/%y")), ]
dim(flightWeatherData78)
str(flightWeatherData78)
# write.csv(x = df, file = "a.csv")


df <- flightWeatherData78
df$WeatherDelayType[df$WeatherDelay == 0] <- 1
df$WeatherDelayType[df$WeatherDelay != 0] <- 2





# Percent missing value for each variable
misVal<-sapply(df1, function(x) (sum(is.na(x))/nrow(df)*100))
perMis <- round(misVal, 1)
perMis



# Exploring individual variables
# use summary and quantile for continuous variables; 
# use table for categorical variables.

# continuous variable :- DepDelay
summary(df$DepDelay)
quantile(df$DepDelay, probs = seq(0, 1, by= 0.05), na.rm=TRUE)
quantile(df$DepDelay, probs = seq(0.95, 1, by= 0.01), na.rm=TRUE)
# So the values above 306 can be capped at 306
# capping values 
# df$ActualElapsedTime[df$ActualElapsedTime > 306] <- 306

# categorical variable :- Events
table(df$Events, useNA = "always")








