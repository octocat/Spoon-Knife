# flight features:
rm(list=ls())
col <- c(1, 2, 3, 4, 9, 16, 17, 18, 26)

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy[, col]
str(flightData2007)

# subsetting flight data for year 2007 for particular carrier and origin
subsetflightData2007 <- subset(flightData2007, (UniqueCarrier == "AA") & (Origin == "DFW"))
nrow(subsetflightData2007)

# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# combining Year, Month and DayOfMonth columns of flightData78
subsetflightData2007$CST <- with(subsetflightData2007, paste(Year, Month, DayofMonth, sep = "-"))
str(subsetflightData2007$CST)

# Variables: Year, Month, DayofMonth, DayOfWeek, DepTime, ArrTime,UniqueCarrier, ArrDelay, 
# DepDelay, Origin, Dest, Distance,TaxiIn, TaxiOut, CarrierDelay, WeatherDelay, NASDelay, 
# SecurityDelay,LateAircraftDelay


# merging flightData78 and weatherData78 by column CST
weatherData2007$CST <- trimws(weatherData2007$CST)
flightWeatherData2007 <- merge(x = subsetflightData2007, y = weatherData2007, by = "CST")
str(flightWeatherData2007)
dim(flightWeatherData2007)

# convert to date data-type
flightWeatherData2007$CST <- as.Date(as.character(flightWeatherData2007$CST, format = "%Y/%m/%d"))

# sorting data datewise
flightWeatherData2007 <- flightWeatherData2007[order(as.Date(flightWeatherData2007$CST, format = "%Y/%m/%d")), ]
dim(flightWeatherData2007)
str(flightWeatherData2007)
# write.csv(x = df1, file = "a.csv")


df <- flightWeatherData2007
# applying summary(lm(df$WeatherDelay ~ .)) w.r.t. weather related variables.

# columns having negative linear relationship with WeatherDelay column.
col1 <- c(20, 21, 22, 24, 25, 27)

df1 <- df[, -col1]

# removing NA's
# df1$DepDelay <- complete.cases(df1$DepDelay)
# df1$Max.Gust.SpeedMPH <- complete.cases(df1$Max.Gust.SpeedMPH)
str(df1)
