
# flight features:
rm(list=ls())
# columns not included in flightdata2007 as these columns are irrelevant
col <- c(10, 11, 25, 27, 28, 29)

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy[, -col]
str(flightData2007)

# subsetting flight data for year 2007 for particular carrier and origin
subsetflightData2007 <- subset(flightData2007, (Origin == "DFW"))
str(subsetflightData2007)
dim(subsetflightData2007)

# changing datatypes of some columns of subsetflightData2007
# subsetflightData2007$Month <- as.factor(subsetflightData2007$Month)
# subsetflightData2007$DayofMonth <- as.factor(subsetflightData2007$DayofMonth)
# subsetflightData2007$DayOfWeek <- as.factor(subsetflightData2007$DayOfWeek)
# subsetflightData2007$Diverted <- as.factor(subsetflightData2007$Diverted)

# combining Year, Month and DayOfMonth columns of flightData78
subsetflightData2007$CST <- with(subsetflightData2007, 
                                 paste(Year, Month, DayofMonth, sep = "-"))
str(subsetflightData2007$CST)

# changing datatype of CST of flightData2007
subsetflightData2007$CST <- as.Date(as.character(subsetflightData2007$CST, 
                                                 format = "%Y/%m/%d"))
str(subsetflightData2007$CST)

# sorting data datewise
subsetflightData2007 <- subsetflightData2007[order(as.Date(subsetflightData2007$CST, 
                                                             format = "%Y/%m/%d")), ]
head(subsetflightData2007$CST)
# complete subsetflightData2007


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, format = "%Y/%m/%d"))
# complete weatherData2007

# NA checking
# finding columns having NA's from weatherData2007
colnames(weatherData2007)[apply(is.na(weatherData2007), 2, any)]

# finding columns having NA's from subsetflightData2007
colnames(subsetflightData2007)[apply(is.na(subsetflightData2007), 2, any)]

# finding percentage of missig values in variables from subsetflightData2007
misVal<-sapply(subsetflightData2007, function(x) (sum(is.na(x))/nrow(df)*100))
perMis <- round(misVal, 1)
perMis


# merging flightData78 and weatherData78 by column CST
flightWeatherData2007 <- merge(x = subsetflightData2007, y = weatherData2007, by = "CST")
str(flightWeatherData2007)
dim(flightWeatherData2007)
# complete flightWeatherData2007


df <- flightWeatherData2007
# write.csv(x = df, file = "a.csv")
# applying summary(lm(df$WeatherDelay ~ .)) w.r.t. weather related variables.
# or cor(df$WeatherDelay, ...) w.r.t. weather related variables.

# columns having negative linear relationship with WeatherDelay column.
col1 <- c(13, 21, 23, 34, 35, 36, 38, 39, 41)

# columns having negative linear relationship with DepDelay column. 
col2 <- c(25, 26, 34:39, 41)

# df$cancelled is having 0 covariance with DepDelay column.

# variable selection
# newFlightWeatherData2007 <- flightWeatherData2007

# columns not included in newFlightWeatherData2007 as these columns are irrelevant
# col3 <- c(1:5, 10, 16, 17, 22)
# library(leaps)
# library(MASS)
# reg2 <- regsubsets(WeatherDelay ~ ., data = newFlightWeatherData2007[, -col3], 
#                    nvmax = 10, method = "forward")
# summary(reg2)
