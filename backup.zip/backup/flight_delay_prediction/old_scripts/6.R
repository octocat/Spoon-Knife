
# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)
str(flightData2007)

# subsetting flight data for year 2007 for particular origin
 subsetflightData2007 <- subset(flightData2007, (Origin == "DFW")
                                & (Cancelled == 1 & CancellationCode == "B" | 
                                           WeatherDelay > 0))
# subsetflightData2007 <- subset(flightData2007, (Origin == "DFW" & WeatherDelay > 0))
dim(subsetflightData2007)
str(subsetflightData2007)


# combining Year, Month and DayOfMonth columns of flightData78
subsetflightData2007$CST <- with(subsetflightData2007, 
                                 paste(Year, Month, DayofMonth, sep = "-"))
str(subsetflightData2007$CST)

# changing datatype of CST of flightData2007
subsetflightData2007$CST <- as.Date(as.character(subsetflightData2007$CST, 
                                                 format = "%Y/%m/%d"))
str(subsetflightData2007$CST)

# sorting data datewise
subsetflightData2007 <- subsetflightData2007[order(as.Date(subsetflightData2007$CST, 
                                                           format = "%Y/%m/%d")), ]
head(subsetflightData2007$CST)
# complete subsetflightData2007


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, format = "%Y/%m/%d"))
# complete weatherData2007

# NA checking
# finding columns having NA's from weatherData2007
colnames(weatherData2007)[apply(is.na(weatherData2007), 2, any)]

# finding columns having NA's from subsetflightData2007
colnames(subsetflightData2007)[apply(is.na(subsetflightData2007), 2, any)]

# finding percentage of missig values in variables from subsetflightData2007
misVal<-sapply(flightWeatherData2007, function(x) (sum(is.na(x))/nrow(flightWeatherData2007)*100))
perMis <- round(misVal, 1)
perMis


# merging flightData78 and weatherData78 by column CST
flightWeatherData2007 <- merge(x = subsetflightData2007, y = weatherData2007, by = "CST")
dim(flightWeatherData2007)
str(flightWeatherData2007)
# complete flightWeatherData2007
# write.csv(x = flightWeatherData2007, file = "subset.csv")

# columns not included in flightWeatherData2007 as these columns are irrelevant
names(flightWeatherData2007)
col <- c(11, 12, 26, 28:30)
df <- flightWeatherData2007[, -col]
names(df)

# using linear model i.e. lm() for variable selection for continuous variables 
summary(lm(df$WeatherDelay ~ ., df[, -c(1:5, 10, 18, 26, 28:30)]))
# col_cont <- c(1, 2, 6, 8, 10, 13:20, 24)

# Using chisq.test on categorical variables.
# tabulating data for chi-sq test 
tab<- table(df$WeatherDelay, df$PrecipitationIn)  
# chi-sq test for categorical variable 
chisq.test(tab)

tab1<- table(df$WeatherDelay, df$Events)  
chisq.test(tab1)
# col_cat <- c(21, 23)
# col_all <- c(col_cont, col_cat)
# 
# df2 <- df[, col_all]
# names(df1)
# dim(df2)

