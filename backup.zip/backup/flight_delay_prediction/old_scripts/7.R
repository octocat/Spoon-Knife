# Aim :- For predicting DepDelay / cancellation of flight due to WeatherDelay.
# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)
str(flightData2007)

# subsetting flight data for year 2007 for particular origin
subsetFlightData2007 <- subset(flightData2007, (Origin == "DFW")
                               & (Cancelled == 1 & CancellationCode == "B" | 
                                          WeatherDelay > 0))
dim(subsetFlightData2007)
str(subsetFlightData2007)

# combining Year, Month and DayOfMonth columns of flightData78
subsetFlightData2007$CST <- with(subsetFlightData2007, 
                                 paste(Year, Month, DayofMonth, sep = "-"))
str(subsetFlightData2007$CST)

# changing datatype of CST of flightData2007
subsetFlightData2007$CST <- as.Date(as.character(subsetFlightData2007$CST, 
                                                 format = "%Y/%m/%d"))
str(subsetFlightData2007$CST)

# sorting data datewise
subsetFlightData2007 <- subsetFlightData2007[order(as.Date(subsetFlightData2007$CST, 
                                                           format = "%Y/%m/%d")), ]
head(subsetFlightData2007$CST)
# complete subsetFlightData2007

# subsetting subsetflightData2007 for delayed flights
delayedFlightData2007 <- subset(subsetFlightData2007, (WeatherDelay > 0))
dim(delayedFlightData2007)

# subsetting subsetflightData2007 for cancelled flights
cancelSubsetFlightData2007 <- subset(subsetFlightData2007, (Cancelled == 1))
dim(cancelSubsetFlightData2007)

# first we consider delayed flights


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, format = "%Y/%m/%d"))
# complete weatherData2007

# NA checking
# finding columns having NA's from weatherData2007
colnames(weatherData2007)[apply(is.na(weatherData2007), 2, any)]

# finding columns having NA's from delayedFlightData2007
colnames(delayedFlightData2007)[apply(is.na(delayedFlightData2007), 2, any)]


# merging flightData78 and weatherData78 by column CST
delayedFlightWeatherData2007 <- merge(x = delayedFlightData2007, y = weatherData2007, by = "CST")
dim(delayedFlightWeatherData2007)
str(delayedFlightWeatherData2007)
# complete delayedFlightWeatherData2007
# write.csv(x = delayedFlightWeatherData2007, file = "delayedFlightWeatherData2007.csv")


# columns not included in flightWeatherData2007 as these columns are irrelevant
names(delayedFlightWeatherData2007)
col <- c(11, 12, 23, 24, 26, 28:30)
delayedDf <- delayedFlightWeatherData2007[, -col]
names(delayedDf)

# # using linear model i.e. lm() for variable selection for continuous variables 
# summary(lm(delayedDf$WeatherDelay ~ ., delayedDf[, -c(1:5, 10, 15:17, 21, 41, 43)]))
# 
# # Using chisq.test on categorical variables.
# # tabulating data for chi-sq test 
# tab<- table(delayedDf$WeatherDelay, delayedDf$PrecipitationIn)  
# # chi-sq test for categorical variable 
# chisq.test(tab)
# 
# tab1<- table(delayedDf$WeatherDelay, delayedDf$Events)  
# chisq.test(tab1)

