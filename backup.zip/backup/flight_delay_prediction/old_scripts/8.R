# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)
str(flightData2007)

# subsetting flight data for year 2007 for particular origin
subsetFlightData2007 <- subset(flightData2007, (Origin == "DFW"))
dim(subsetFlightData2007)
str(subsetFlightData2007)

# subsetting flight data for year 2007 for particular origin and WeatherDelay > 0
subsetWDelayedFlightData2007 <- subset(flightData2007, (Origin == "DFW")
                               & (WeatherDelay > 0))

dim(subsetWDelayedFlightData2007)
str(subsetWDelayedFlightData2007)

# first we consider subsetWDelayedFlightData2007

# combining Year, Month and DayOfMonth columns of flightData78
subsetWDelayedFlightData2007$CST <- with(subsetWDelayedFlightData2007, 
                                 paste(Year, Month, DayofMonth, sep = "-"))
str(subsetWDelayedFlightData2007$CST)

# changing datatype of CST of flightData2007
subsetWDelayedFlightData2007$CST <- as.Date(as.character(subsetWDelayedFlightData2007$CST, 
                                                 format = "%Y/%m/%d"))
str(subsetWDelayedFlightData2007$CST)

# sorting data datewise
subsetWDelayedFlightData2007 <- subsetWDelayedFlightData2007[order(as.Date(
                                        subsetWDelayedFlightData2007$CST, 
                                                format = "%Y/%m/%d")), ]
head(subsetWDelayedFlightData2007$CST)


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, format = "%Y/%m/%d"))
# complete weatherData2007

# merging flightData78 and weatherData78 by column CST
WDelayedFlightWeatherData2007 <- merge(x = subsetWDelayedFlightData2007, 
                                      y = weatherData2007, by = "CST")
dim(WDelayedFlightWeatherData2007)
str(WDelayedFlightWeatherData2007)
# complete delayedFlightWeatherData2007
# write.csv(x = WDelayedFlightWeatherData2007, file = "WDelayedFlightWeatherData2007.csv")


# columns not included in flightWeatherData2007 as these columns are irrelevant
names(WDelayedFlightWeatherData2007)
col <- c(11, 12, 23, 24, 26, 28:30)
delayedDf <- WDelayedFlightWeatherData2007[, -col]
names(delayedDf)

# for median
summary(delayedDf$WeatherDelay)

# creating new variable WDelay as binary(it is dependent variable)
delayedDf$WDelay[delayedDf$WeatherDelay <= 18] <- 0
delayedDf$WDelay[delayedDf$WeatherDelay > 18] <- 1

# irrelevant columns
col1 <- c(1:5, 10, 16, 17, 22)

# for significant variables
a <- lm(WDelay ~ ., data = delayedDf[, -col1])
anova(a)

# columns having low significance
col2 <- c(13, 18, 19, 24, 30, 33)

col3 <- c(col1, col2)

dataset <- delayedDf[, -col3]
names(dataset)
# create training and test data
library(caret)
inTrain <- createDataPartition(y=dataset$WDelay, p=0.7, list=FALSE)

training <- dataset[inTrain,]
dim(training)
testing <- dataset[-inTrain,]
dim(testing)

# apply logistic regression on train data
# fitting stepwise binary logistic regression with logit link function 
# mod<-step(glm(WDelay ~ ., family = binomial(link=logit),data = training))
names(training)
mod <- glm(WDelay ~ ., family = "binomial" , data = training[, -c(8, 10)])
# model summary 
summary(mod)

names(training)
