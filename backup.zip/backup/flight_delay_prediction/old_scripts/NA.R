# finding columns having NA's from weatherData2007
colnames(weatherData2007)[apply(is.na(weatherData2007), 2, any)]

# finding columns having NA's from subsetflightData2007
colnames(subsetflightData2007)[apply(is.na(subsetflightData2007), 2, any)]

# finding percentage of missig values in variables from subsetflightData2007
misVal<-sapply(subsetflightData2007, function(x) (sum(is.na(x))/nrow(df)*100))
perMis <- round(misVal, 1)
perMis

