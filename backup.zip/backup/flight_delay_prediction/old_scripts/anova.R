# finding correlation between weatherDelay and variables of weatherData
# lm1 <- lm(WeatherDelay ~ ., df[, -c(1, 21, 23)])
# summary(lm1)
# 
# lm2 <- lm(WeatherDelay ~ ., df[, c(2, 6:8, 13, 14, 16:20, 21, 23, 24)])
# summary(lm2)

# compMod <- anova(lm1, lm2)
# compMod