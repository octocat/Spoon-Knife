# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)
str(flightData2007)

# subsetting flight data for year 2007 for particular origin
subsetFlightData2007 <- subset(flightData2007, (Origin == "DFW"))
dim(subsetFlightData2007)
str(subsetFlightData2007)

# subsetting flight data for year 2007 for particular origin and WeatherDelay > 0
subsetWDelayedFlightData2007 <- subset(flightData2007, (Origin == "DFW")
                                       & (WeatherDelay > 0))

dim(subsetWDelayedFlightData2007)
str(subsetWDelayedFlightData2007)

# first we consider subsetWDelayedFlightData2007

# combining Year, Month and DayOfMonth columns of flightData78
subsetWDelayedFlightData2007$CST <- with(subsetWDelayedFlightData2007, 
                                         paste(Year, Month, DayofMonth, sep = "-"))
str(subsetWDelayedFlightData2007$CST)

# changing datatype of CST of flightData2007
subsetWDelayedFlightData2007$CST <- as.Date(as.character(subsetWDelayedFlightData2007$CST, 
                                                         format = "%Y/%m/%d"))
str(subsetWDelayedFlightData2007$CST)

# sorting data datewise
subsetWDelayedFlightData2007 <- subsetWDelayedFlightData2007[order(as.Date(
        subsetWDelayedFlightData2007$CST, 
        format = "%Y/%m/%d")), ]
head(subsetWDelayedFlightData2007$CST)


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, format = "%Y/%m/%d"))
# complete weatherData2007

# merging flightData78 and weatherData78 by column CST
WDelayedFlightWeatherData2007 <- merge(x = subsetWDelayedFlightData2007, 
                                       y = weatherData2007, by = "CST")
dim(WDelayedFlightWeatherData2007)
str(WDelayedFlightWeatherData2007)
# complete delayedFlightWeatherData2007
# write.csv(x = WDelayedFlightWeatherData2007, file = "WDelayedFlightWeatherData2007.csv")


# columns not included in flightWeatherData2007 as these columns are irrelevant
names(WDelayedFlightWeatherData2007)
col <- c(11, 12, 23, 24, 26, 28:30)
delayedDf <- WDelayedFlightWeatherData2007[, -col]
names(delayedDf)

# for median
summary(delayedDf$WeatherDelay)

# creating new variable WDelay as binary(it is dependent variable)
delayedDf$WDelay[delayedDf$WeatherDelay <= 18] <- 0
delayedDf$WDelay[delayedDf$WeatherDelay > 18] <- 1
# delayedDf$WDelay <- as.factor(delayedDf$WDelay)

# irrelevant columns
col1 <- c(1:5, 10, 16, 17, 21, 22)

dataset <- delayedDf[, -col1]
names(dataset)
# create training and test data
library(caret)
inTrain <- createDataPartition(y=dataset$WDelay, p=0.7, list=FALSE)

training <- dataset[inTrain,]
dim(training)
testing <- dataset[-inTrain,]
dim(testing)

names(training)

# install.packages("devtools") 
library(devtools) 
# install_github("tomasgreif/woe") 
library(woe)
# calculation of information value 
training$WDelay <- as.factor(training$WDelay)
row.names(training) <- 1:nrow(training) 
IV <- iv.mult(training, y="WDelay", TRUE)
iv.plot.summary(IV)
# IV <- iv.mult(d[, -1], y="DepDelay", TRUE)

# selecting variables with 0.1<IV<0.5
var <- IV[which(IV$InformationValue > 0.1),]
var1 <- var[which(var$InformationValue < 0.5),]
final_var <- var1$Variable
WDelay <- training$WDelay
training_new <- training[final_var]
training_final<-cbind(WDelay, training_new) 
names(training_final)

mod <- glm(WDelay ~ ., family = binomial(logit), data = training_final)
summary(mod)

names(training_final)
training_final1 <- training_final[, -c(5:8)]
model <- glm(WDelay ~ ., family = binomial(logit), data = training_final1)
summary(model)

library(ResourceSelection) 
hoslem.test(as.numeric(training_final1$WDelay), model$fitted.values, g = 10) 

# Prediction on test set 
pred_prob<-predict (model, newdata=testing, type="response") 

# model accuracy measures 
library (ROCR) 
pred <- prediction (pred_prob, testing$WDelay)

# Area under the curve 
performance (pred, 'auc') 

# creating ROC curve 
roc <- performance (pred,"tpr","tnr") 
plot (roc)

# create data frame of values 
perf <-as.data.frame(cbind(roc@alpha.values[[1]], roc@x.values[[1]], roc@y.values[[1]])) 
colnames(perf) <-c("Probability","TNR","TPR") 

# removing infinity value from data frame 
perf <-perf[-1,] 

# reshape the data frame 
library(reshape) 
perf2<- melt(perf, measure.vars = c("TNR", "TPR")) 

# plotting FPR, TPR on y axis and cut-off probability on x axis 
library(ggplot2) 
ggplot(perf2, aes(Probability, value, colour = variable)) +    
        geom_line()+ theme_bw()

# model accuracy - Confusion Matrix 
library(SDMTools) 
confusion.matrix (testing$WDelay, pred_prob, threshold = 0.5) 

# Prediction on test set of CAX 
pred_CAX<- predict(model, newdata=testing, type="response") 
submit_CAX<- cbind(testing$WDelay, pred_CAX) 
colnames(submit_CAX)<- c("WDelay", "Prob") 
write.csv(submit_CAX,"Predictions.csv",row.names=F)


par(mfrow= c(2, 2))
cdplot(training_final1$WDelay ~ training_final1$Max.TemperatureF, xlab = "Max.Temp", ylab = "WDelay")
cdplot(training_final1$WDelay ~ training_final1$MeanDew.PointF, xlab = "Mean.DewPoint", ylab = "WDelay")
cdplot(training_final1$WDelay ~ training_final1$Min.DewpointF, xlab = "Min.DewPoint", ylab = "WDelay")
cdplot(training_final1$WDelay ~ training_final1$ArrDelay, xlab = "ArrDelay", ylab = "WDelay")

library(lattice)
xyplot(training_final1$WDelay ~ training_final1$Max.TemperatureF | training_final1$Events, 
       xlab = "Max.Temp", ylab = "WDelay")

xyplot(training_final1$WDelay ~ training_final1$MeanDew.PointF | training_final1$Events, 
       xlab = "Mean.DewPoint", ylab = "WDelay")

xyplot(training_final1$WDelay ~ training_final1$Min.DewpointF | training_final1$Events, 
       xlab = "Min.DewPoint", ylab = "WDelay")

xyplot(training_final1$WDelay ~ training_final1$ArrDelay | training_final1$Events, 
       xlab = "ArrDelay", ylab = "WDelay")

xyplot(training_final1$WDelay ~ training_final1$Max.TemperatureF + training_final1$MeanDew.PointF
       + training_final1$Min.DewpointF + training_final1$ArrDelay | training_final1$Events, ylab = "WDelay")
