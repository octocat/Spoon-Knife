# flight features:
# rm(list=ls())

# reading flight data for year 2007
flightData2007Copy <- read.csv(file = "2007.csv")
flightData2007 <- flightData2007Copy
dim(flightData2007)
str(flightData2007)

# subsetting flight data for year 2007 for particular origin and WeatherDelay > 0
subsetWDelayedFlightData2007 <- subset(flightData2007, (Origin == "DFW")
                                       & (WeatherDelay > 0))

dim(subsetWDelayedFlightData2007)
str(subsetWDelayedFlightData2007)

# first we consider subsetWDelayedFlightData2007

# combining Year, Month and DayOfMonth columns of flightData78
subsetWDelayedFlightData2007$CST <- with(subsetWDelayedFlightData2007, 
                                         paste(Year, Month, DayofMonth, sep = "-"))
str(subsetWDelayedFlightData2007$CST)

# changing datatype of CST of flightData2007
subsetWDelayedFlightData2007$CST <- as.Date(as.character(subsetWDelayedFlightData2007$CST, 
                                                         format = "%Y/%m/%d"))
str(subsetWDelayedFlightData2007$CST)

# sorting data datewise
subsetWDelayedFlightData2007 <- subsetWDelayedFlightData2007[order(as.Date(
        subsetWDelayedFlightData2007$CST, 
        format = "%Y/%m/%d")), ]
head(subsetWDelayedFlightData2007$CST)


# Weather features:
# reading weather data for year 2007
weatherData2007 <- read.csv(file = "DFW_2007.csv")
dim(weatherData2007)
str(weatherData2007)

# changing datatype of CST of weatherData2007
weatherData2007$CST <- trimws(weatherData2007$CST)
weatherData2007$CST <- as.Date(as.character(weatherData2007$CST, format = "%Y/%m/%d"))
# complete weatherData2007

# merging flightData78 and weatherData78 by column CST
WDelayedFlightWeatherData2007 <- merge(x = subsetWDelayedFlightData2007, 
                                       y = weatherData2007, by = "CST")
dim(WDelayedFlightWeatherData2007)
str(WDelayedFlightWeatherData2007)
# complete delayedFlightWeatherData2007
# write.csv(x = WDelayedFlightWeatherData2007, file = "WDelayedFlightWeatherData2007.csv")


# columns not included in flightWeatherData2007 as these columns are irrelevant
names(WDelayedFlightWeatherData2007)
col <- c(11, 12, 23, 24, 26, 28:30)
delayedDf <- WDelayedFlightWeatherData2007[, -col]
names(delayedDf)

# for median
summary(delayedDf$WeatherDelay)

# creating new variable WDelay as binary(it is dependent variable)
delayedDf$WDelay[delayedDf$WeatherDelay <= 18] <- 0
delayedDf$WDelay[delayedDf$WeatherDelay > 18] <- 1
# delayedDf$WDelay <- as.factor(delayedDf$WDelay)

# irrelevant columns
col1 <- c(6:21)

dataset <- delayedDf[, -col1]
names(dataset)


# variable selection
# install.packages("devtools") 
library(devtools) 
# install_github("tomasgreif/woe") 
library(woe)
# calculation of information value 
row.names(dataset) <- 1:nrow(dataset) 
IV <- iv.mult(dataset[, -c(1:6)], y="WDelay", TRUE)
IV
iv.plot.summary(IV)
# IV <- iv.mult(d[, -1], y="DepDelay", TRUE)

# selecting variables with 0.1<IV<0.5
var <- IV[which(IV$InformationValue > 0.1),]
var1 <- var[which(var$InformationValue < 0.5),]

final_var <- var1$Variable
WDelay <- dataset$WDelay
WeatherDelay <- dataset$WeatherDelay
dataset_new <- dataset[final_var]
dataset_final<-cbind(dataset[, c(1:5)], dataset_new, WeatherDelay, WDelay) 
names(dataset_final) # final variables
# [1] "PrecipitationIn"   "Events"            "Min.DewpointF"     "Max.Gust.SpeedMPH"
# [5] "Max.Wind.SpeedMPH" "MeanDew.PointF"    "WindDirDegrees" 
str(dataset_final)
# write.csv(x = dataset_final, file = "dataset_final.csv")


# # more on variable selection
# # for numeric variables
# summary(lm(as.numeric(dataset_final$WDelay)~dataset_final$Max.Wind.SpeedMPH))
# # windDirDegrees has less significance
# 
# # tabulating data for chi-sq test
# tab<- table(dataset_final$WDelay, dataset_final$Events)
# # chi-sq test for categorical variable
# chisq.test(tab)
# 
# # outliers
# # finding outliers w.r.t. Wdelay
# plot(dataset_final$WDelay, dataset_final$Max.Gust.SpeedMPH)
# 
# # finding outliers of continuous variables
# a <- boxplot(dataset_final$Max.Gust.SpeedMPH)
# a$stats


# dataset without outlier
dataset_final_wo_outlier <- subset(dataset_final, (Max.Gust.SpeedMPH <= 47 & 
                                   MeanDew.PointF >= 19 & Max.Wind.SpeedMPH <= 39 & 
                                           dataset_final$WeatherDelay <= 94))
dim(dataset_final_wo_outlier)
names(dataset_final_wo_outlier)
# write.csv(x = dataset_final_wo_outlier, file = "dataset_final_wo_outlier.csv")

# bucketing each variable
df <- dataset_final_wo_outlier

