# install developer tool and then woe package from gitub 
# refer http://www.r-bloggers.com/r-credit-scoring-woe-information-value-in-woepackage/
install.packages("devtools") 
library(devtools) 
install_github("tomasgreif/woe") 
library(woe)

d <- delayedDf
names(d)
# row.names(d) <- 1:nrow(d) 

# table(d$WeatherDelay, useNA = "always")

d$WDelay[d$WeatherDelay <= 10] <- 0
d$WDelay[d$WeatherDelay > 10] <- 1

# calculation of information value 
IV <- iv.mult(d[, -c(1:5, 10, 16, 17)], y="WDelay", TRUE)
# IV <- iv.mult(d[, -1], y="DepDelay", TRUE)

# selecting variables with 0.1<IV<0.5
var <- IV[which(IV$InformationValue > 0.1),]
var1 <- var[which(var$InformationValue < 0.5),]
final_var <- var1$Variable
WeatherDelay <- d$WeatherDelay
WDelay <- d$WDelay
d_new <- d[final_var]
d_final<-cbind(WDelay, d_new) 
names(d_final)
