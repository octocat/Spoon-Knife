# fitting stepwise binary logistic regression with logit link function 
mod<-step(glm(WDelay ~ ., family = binomial(link=logit),data = d_final))

# model summary 
summary(mod) 

names(d_final)
d_final1 <- d_final[, -c(2, 4, 5, 9, 11)]

model<-step(glm(WDelay ~ ., family = binomial(link=logit),data = d_final1))
summary(model)

# model fit (Hosmer and Lemeshow goodness of fit (GOF) test) 
library(ResourceSelection) 
hoslem.test(d_final1$WDelay,mod$fitted.values, g=10) 

d_final2 <- delayedDf[, -c(1:5, 10, 16, 17)]
names(d_final2)

a <- lm(WDelay ~ ., data = d_final2)
anova(a)

b <- lm(WDelay ~ ., data = d_final[, -c(8, 9)])
anova(b)

hoslem.test(d_final$WDelay,b$fitted.values, g=10)
