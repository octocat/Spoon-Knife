library(leaps)
library(MASS)
reg1 <- regsubsets(perf ~ syct + mmin + mmax + cach + chmin + chmax,
           data = cpus, nvmax = 4)
summary(reg1)

reg2 <- regsubsets(WeatherDelay ~ ., data = flightWeatherData2007, nvmax = 10)
