# from explore2.R
# finding probabilities for weatherdelay eventwise 
# 1. Fog event:- temperature and dewpoint
dataset_final_Fog <- subset(dataset_final, Events == "Fog")
dim(dataset_final_Fog)

# finding ranges
minMaxTemp <- min(dataset_final_Fog$Max.TemperatureF)
minMaxTemp
maxMaxTemp <- max(dataset_final_Fog$Max.TemperatureF)
maxMaxTemp

minMeanTemp <- min(dataset_final_Fog$Mean.TemperatureF)
minMeanTemp
maxMeanTemp <- max(dataset_final_Fog$Mean.TemperatureF)
maxMeanTemp

minMinTemp <- min(dataset_final_Fog$Min.TemperatureF)
minMinTemp
maxMinTemp <- max(dataset_final_Fog$Min.TemperatureF)
maxMinTemp

minMaxDew <- min(dataset_final_Fog$Max.Dew.PointF)
minMaxDew
maxMaxDew <- max(dataset_final_Fog$Max.Dew.PointF)
maxMaxDew

minMeanDew <- min(dataset_final_Fog$MeanDew.PointF)
minMeanDew
maxMeanDew <- max(dataset_final_Fog$MeanDew.PointF)
maxMeanDew

minMinDew <- min(dataset_final_Fog$Min.DewpointF)
minMinDew
maxMinDew <- max(dataset_final_Fog$Min.DewpointF)
maxMinDew

# minMaxHumidity <- min(dataset_final_Fog$Max.Humidity)
# minMaxHumidity
# maxMaxHumidity <- max(dataset_final_Fog$Max.Humidity)
# maxMaxHumidity
# 
# minMeanHumidity <- min(dataset_final_Fog$Mean.Humidity)
# minMeanHumidity
# maxMeanHumidity <- max(dataset_final_Fog$Mean.Humidity)
# maxMeanHumidity
# 
# minMinHumidity <- min(dataset_final_Fog$Min.Humidity)
# minMinHumidity
# minMaxHumidity <- max(dataset_final_Fog$Min.Humidity)
# minMaxHumidity
# 
# minMinVisibility <- min(dataset_final_Fog$Min.VisibilityMiles)
# minMinVisibility
# maxMinVisibility <- max(dataset_final_Fog$Min.VisibilityMiles)
# maxMinVisibility
# 
# minMaxWind <- min(dataset_final_Fog$Max.Wind.SpeedMPH)
# minMaxWind
# maxMaxWind <- max(dataset_final_Fog$Max.Wind.SpeedMPH)
# maxMaxWind
# 
# minMaxGust <- min(dataset_final_Fog$Max.Gust.SpeedMPH)
# minMaxGust
# maxMaxGust <- max(dataset_final_Fog$Max.Gust.SpeedMPH)
# maxMaxGust
# 
