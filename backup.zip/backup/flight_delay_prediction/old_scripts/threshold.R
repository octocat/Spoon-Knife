# continue from completeBuckettedModel2008.R

# Prediction on test set
pred_prob <- predict(mod, newdata = testing, type = "response")

# model accuracy measures
library(ROCR)
pred <- prediction(pred_prob, testing$WDelay)

# Area under the curve
performance(pred, 'auc')

# creating ROC curve
roc <- performance (pred,"tpr","tnr")
plot (roc)


# create data frame of values
perf <- as.data.frame(cbind(roc@alpha.values[[1]], roc@x.values[[1]], roc@y.values[[1]]))
colnames(perf) <-c("Probability","TNR","TPR")

# removing infinity value from data frame
perf <-perf[-1,]

# reshape the data frame
library(reshape)
perf2<- melt(perf, measure.vars = c("TNR", "TPR"))

# plotting FPR, TPR on y axis and cut-off probability on x axis
library(ggplot2)
ggplot(perf2, aes(Probability, value, colour = variable)) +
        geom_line()+ theme_bw()



f2 <- approxfun(perf2$value, perf2$Probability)
v0 <- 0.77
f2(v0)
# 0.0416565