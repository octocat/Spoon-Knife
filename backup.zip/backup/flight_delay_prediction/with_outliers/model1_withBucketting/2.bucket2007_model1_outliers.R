# continue from 1.explore2007_model1.R
names(dataset_final2007)
# [1] "CST"                       "Year"                      "Month"                    
# [4] "DayofMonth"                "DayOfWeek"                 "Origin"                   
# [7] "Dest"                      "Mean.TemperatureF"         "MeanDew.PointF"           
# [10] "Mean.Sea.Level.PressureIn" "Max.Wind.SpeedMPH"         "Max.Gust.SpeedMPH"        
# [13] "Events"                    "WindDirDegrees"            "WeatherDelay"             
# [16] "WDelay" 

dataset_final2007 <- dataset_final2007[, -10]
names(dataset_final2007)
# [1] "CST"               "Year"              "Month"             "DayofMonth"       
# [5] "DayOfWeek"         "Origin"            "Dest"              "Mean.TemperatureF"
# [9] "MeanDew.PointF"    "Max.Wind.SpeedMPH" "Max.Gust.SpeedMPH" "Events"           
# [13] "WindDirDegrees"    "WeatherDelay"      "WDelay"   

 write.csv(x = dataset_final2007, file = "model1_withBucketting/dataset_final2007.csv")


# bucketing variables randomly***
tempDatasetFinal2007 <- dataset_final2007

# finding minimum and maximum
minMeanTemp <- min(tempDatasetFinal2007$Mean.TemperatureF)
minMeanTemp
maxMeanTemp <- max(tempDatasetFinal2007$Mean.TemperatureF)
maxMeanTemp

# finding ranges corresponding to 10 buckets
a <- quantile(tempDatasetFinal2007$Mean.TemperatureF, probs = seq(0, 1, by = 0.1))
a
# 0%  10%  20%  30%  40%  50%  60%  70%  80%  90% 100% 
# 29   44   51   60   67   71   76   81   83   86   93 

summary(tempDatasetFinal2007$Mean.TemperatureF)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$Mean.TemperatureF[tempDatasetFinal2007$Mean.TemperatureF > lowRange & 
                                                           tempDatasetFinal2007$Mean.TemperatureF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Mean.TemperatureF)
quantile(tempDatasetFinal2007$Mean.TemperatureF, probs = seq(0, 1, by = 0.1))

minMeanDew <- min(tempDatasetFinal2007$MeanDew.PointF)
minMeanDew
maxMeanDew <- max(tempDatasetFinal2007$MeanDew.PointF)
maxMeanDew

a <- quantile(tempDatasetFinal2007$MeanDew.PointF, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$MeanDew.PointF)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$MeanDew.PointF[tempDatasetFinal2007$MeanDew.PointF > lowRange & 
                                                           tempDatasetFinal2007$MeanDew.PointF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$MeanDew.PointF)
quantile(tempDatasetFinal2007$MeanDew.PointF, probs = seq(0, 1, by = 0.1))

minWind <- min(tempDatasetFinal2007$Max.Wind.SpeedMPH)
minWind
maxWind <- max(tempDatasetFinal2007$Max.Wind.SpeedMPH)
maxWind

a <- quantile(tempDatasetFinal2007$Max.Wind.SpeedMPH, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$Max.Wind.SpeedMPH)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$Max.Wind.SpeedMPH[tempDatasetFinal2007$Max.Wind.SpeedMPH > lowRange & 
                                                        tempDatasetFinal2007$Max.Wind.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Max.Wind.SpeedMPH)
quantile(tempDatasetFinal2007$Max.Wind.SpeedMPH, probs = seq(0, 1, by = 0.1))


minGust <- min(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
minGust
maxGust <- max(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
maxGust

a <- quantile(tempDatasetFinal2007$Max.Gust.SpeedMPH, probs = seq(0, 1, by = 0.1), na.rm = TRUE)
a
summary(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange, na.rm = TRUE))
        tempDatasetFinal2007$Max.Gust.SpeedMPH[tempDatasetFinal2007$Max.Gust.SpeedMPH > lowRange & 
                                                           tempDatasetFinal2007$Max.Gust.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$Max.Gust.SpeedMPH, na.rm = TRUE)
quantile(tempDatasetFinal2007$Max.Gust.SpeedMPH, probs = seq(0, 1, by = 0.1), na.rm = TRUE)


minWindDir <- min(tempDatasetFinal2007$WindDirDegrees)
minWindDir
maxWindDir <- max(tempDatasetFinal2007$WindDirDegrees)
maxWindDir

a <- quantile(tempDatasetFinal2007$WindDirDegrees, probs = seq(0, 1, by = 0.1))
a
summary(tempDatasetFinal2007$WindDirDegrees)
i = 1
while (i < 11) {
        lowRange <- a[i]
        upperRange <- a[i+1]
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal2007$WindDirDegrees[tempDatasetFinal2007$WindDirDegrees > lowRange & 
                                                           tempDatasetFinal2007$WindDirDegrees <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal2007$WindDirDegrees)
quantile(tempDatasetFinal2007$WindDirDegrees, probs = seq(0, 1, by = 0.1))

write.csv(x = tempDatasetFinal2007, file = "model1_withBucketting/bucket.csv")
# bucketing done


