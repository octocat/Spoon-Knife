
# here we choose mean variables
names(dataset)
col <- c(1:7, 10, 13, 24, 26, 29, 30, 8, 31)
dataset_final1<-cbind(dataset[, col])
names(dataset_final1) # final variables
# [1] "CST"               "Year"              "Month"             "DayofMonth"       
# [5] "DayOfWeek"         "Origin"            "Dest"              "Mean.TemperatureF"
# [9] "MeanDew.PointF"    "Max.Wind.SpeedMPH" "Max.Gust.SpeedMPH" "Events"           
# [13] "WindDirDegrees"    "WeatherDelay"      "WDelay"     

str(dataset_final1)

# bucketing variables randomly***
tempDatasetFinal1 <- dataset_final1

# finding minimum and maximum
minMeanTemp <- min(tempDatasetFinal1$Mean.TemperatureF)
minMeanTemp
maxMeanTemp <- max(tempDatasetFinal1$Mean.TemperatureF)
maxMeanTemp
Range <- maxMeanTemp - minMeanTemp
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Mean.TemperatureF)
i = 1
while (i < 11) {
        lowRange <- minMeanTemp + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxMeanTemp){
                upperRange <- maxMeanTemp
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$Mean.TemperatureF[tempDatasetFinal1$Mean.TemperatureF > lowRange & 
                                                   tempDatasetFinal1$Mean.TemperatureF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Mean.TemperatureF)


# finding minimum and maximum
minMeanDew <- min(tempDatasetFinal1$MeanDew.PointF)
minMeanDew
maxMeanDew <- max(tempDatasetFinal1$MeanDew.PointF)
maxMeanDew
Range <- maxMeanDew - minMeanDew
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$MeanDew.PointF)
i = 1
while (i < 11) {
        lowRange <- minMeanDew + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxMeanDew){
                upperRange <- maxMeanDew
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$MeanDew.PointF[tempDatasetFinal1$MeanDew.PointF > lowRange & 
                                                    tempDatasetFinal1$MeanDew.PointF <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$MeanDew.PointF)


# finding minimum and maximum
minWind <- min(tempDatasetFinal1$Max.Wind.SpeedMPH)
minWind
maxWind <- max(tempDatasetFinal1$Max.Wind.SpeedMPH)
maxWind
Range <- maxWind - minWind
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Max.Wind.SpeedMPH)
i = 1
while (i < 11) {
        lowRange <- minWind + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxWind){
                upperRange <- maxWind
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$Max.Wind.SpeedMPH[tempDatasetFinal1$Max.Wind.SpeedMPH > lowRange & 
                                                 tempDatasetFinal1$Max.Wind.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Max.Wind.SpeedMPH)


# finding minimum and maximum
minGust <- min(tempDatasetFinal1$Max.Gust.SpeedMPH)
minGust
maxGust <- max(tempDatasetFinal1$Max.Gust.SpeedMPH)
maxGust
Range <- maxGust - minGust
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$Max.Gust.SpeedMPH)
i = 1
while (i < 11) {
        lowRange <- minGust + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxGust){
                upperRange <- maxGust
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$Max.Gust.SpeedMPH[tempDatasetFinal1$Max.Gust.SpeedMPH > lowRange & 
                                                    tempDatasetFinal1$Max.Gust.SpeedMPH <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$Max.Gust.SpeedMPH)


# finding minimum and maximum
minWindDir <- min(tempDatasetFinal1$WindDirDegrees)
minWindDir
maxWindDir <- max(tempDatasetFinal1$WindDirDegrees)
maxWindDir
Range <- maxWindDir - minWindDir
Range
# finding ranges corresponding to 10 buckets
summary(tempDatasetFinal1$WindDirDegrees)
i = 1
while (i < 11) {
        lowRange <- minWindDir + (i-1)*ceiling(Range/10)
        upperRange <- ceiling(Range/10) + lowRange
        if(upperRange > maxWindDir){
                upperRange <- maxWindDir
        }
        finalRange <- c(lowRange, upperRange)
        medianRange <- round(median(finalRange))
        tempDatasetFinal1$WindDirDegrees[tempDatasetFinal1$WindDirDegrees > lowRange & 
                                                    tempDatasetFinal1$WindDirDegrees <= upperRange ] <- medianRange
        i = i + 1
}
summary(tempDatasetFinal1$WindDirDegrees)

write.csv(x = tempDatasetFinal1, file = "model2_withReBucketting/reBucket.csv")
# bucketing done
